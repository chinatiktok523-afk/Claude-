

def test_codex_pinned_session_relabels_the_model_picker(monkeypatch):
    """Claude Code builds `/model` client-side from these env vars rather than
    asking the proxy, so a codex-pinned session must relabel the picker
    itself."""
    from claude_unlimited import cli
    from claude_unlimited.config import Profile

    for tier in ("FABLE", "OPUS", "SONNET", "HAIKU"):
        for suffix in ("", "_NAME", "_DESCRIPTION"):
            monkeypatch.delenv(f"ANTHROPIC_DEFAULT_{tier}_MODEL{suffix}", raising=False)

    # No host/port/token -> the offline literal fallback (no daemon fetch).
    cli._apply_model_labels(Profile(id="c", name="Codex", kind="codex", priority=1,
                                     automatic=True, enabled=True), [])

    import os
    # The id must stay Anthropic-shaped: openai_models.map_model is keyed on it,
    # AND must equal Claude Code's native tier default so our override REPLACES
    # the native picker entry rather than adding a duplicate beside it.
    assert os.environ["ANTHROPIC_DEFAULT_SONNET_MODEL"] == "claude-sonnet-5-5"
    assert os.environ["ANTHROPIC_DEFAULT_FABLE_MODEL"] == "claude-fable-5-2"
    assert os.environ["ANTHROPIC_DEFAULT_HAIKU_MODEL"] == "claude-haiku-5-5"
    # ...while the visible label names BOTH the Claude tier and the backing GPT.
    assert os.environ["ANTHROPIC_DEFAULT_SONNET_MODEL_NAME"] == "Sonnet 5.5 | GPT-6.1 Terra"
    desc = os.environ["ANTHROPIC_DEFAULT_OPUS_MODEL_DESCRIPTION"]
    assert "Codex" in desc and "high" in desc, desc


def test_non_codex_session_leaves_the_model_picker_alone(monkeypatch):
    """Without a pinned codex Profile the pool can rotate to any kind
    mid-session, so labelling every tier as a GPT model would be wrong."""
    from claude_unlimited import cli
    from claude_unlimited.config import Profile
    import os

    monkeypatch.delenv("ANTHROPIC_DEFAULT_SONNET_MODEL_NAME", raising=False)
    cli._apply_model_labels(None, [Profile(id="a", name="A", kind="oauth", priority=1,
                                            automatic=True, enabled=True, account_uuid="u")])
    assert "ANTHROPIC_DEFAULT_SONNET_MODEL_NAME" not in os.environ

    cli._apply_model_labels(Profile(id="a", name="A", kind="oauth", priority=1,
                                     automatic=True, enabled=True, account_uuid="u"), [])
    assert "ANTHROPIC_DEFAULT_SONNET_MODEL_NAME" not in os.environ


def test_user_set_model_labels_are_never_overridden(monkeypatch):
    from claude_unlimited import cli
    from claude_unlimited.config import Profile
    import os

    monkeypatch.setenv("ANTHROPIC_DEFAULT_SONNET_MODEL_NAME", "My Own Label")
    cli._apply_model_labels(Profile(id="c", name="Codex", kind="codex", priority=1,
                                     automatic=True, enabled=True), [])
    assert os.environ["ANTHROPIC_DEFAULT_SONNET_MODEL_NAME"] == "My Own Label"


def _p(kind, pid="x", **kw):
    from claude_unlimited.config import Profile
    if kind == "oauth":
        kw.setdefault("account_uuid", "u")
    return Profile(id=pid, name=pid, kind=kind, priority=1, automatic=True, enabled=True, **kw)


def _clear(monkeypatch):
    for tier in ("FABLE", "OPUS", "SONNET", "HAIKU"):
        for suffix in ("", "_NAME", "_DESCRIPTION"):
            monkeypatch.delenv(f"ANTHROPIC_DEFAULT_{tier}_MODEL{suffix}", raising=False)


def test_rotated_mixed_pool_uses_provider_neutral_labels(monkeypatch):
    """The picker is read once at launch and can never be updated, but a
    rotated session's provider changes per request — so no vendor-specific
    label can stay correct."""
    from claude_unlimited import cli
    import os
    _clear(monkeypatch)

    cli._apply_model_labels(None, [_p("oauth", "a"), _p("codex", "c")])

    # Names BOTH the Claude tier and the GPT model it maps to: accurate whoever
    # serves, and still says what is being picked.
    assert os.environ["ANTHROPIC_DEFAULT_SONNET_MODEL_NAME"] == "Sonnet 5.5 | GPT-6.1 Terra"
    labels = [os.environ[f"ANTHROPIC_DEFAULT_{t}_MODEL_NAME"] for t in ("FABLE", "OPUS", "SONNET", "HAIKU")]
    assert len(set(labels)) == len(labels), labels  # every entry distinguishable
    assert all("GPT" in l for l in labels), labels  # both providers named
    # Every description must state the reasoning level that tier maps to.
    for tier, level in (("FABLE", "high"), ("OPUS", "high"), ("SONNET", "medium"), ("HAIKU", "low")):
        assert level in os.environ[f"ANTHROPIC_DEFAULT_{tier}_MODEL_DESCRIPTION"]
    # ...and the id still has to be one map_model() understands.
    assert os.environ["ANTHROPIC_DEFAULT_SONNET_MODEL"] == "claude-sonnet-5-5"


def test_codex_labels_come_from_the_live_parity_map_when_reachable(monkeypatch):
    """The picker must name whatever the catalogue actually maps a tier to
    right now (GPT-6 Astra today), not a hand-kept literal that silently went
    stale. When the daemon is reachable the labels are derived from GET
    /v1/models, effort split onto the description line."""
    from claude_unlimited import cli
    from claude_unlimited.config import Profile
    import os
    _clear(monkeypatch)

    # Stand in for the daemon's parity listing.
    monkeypatch.setattr(cli, "_fetch_parity_labels", lambda *a, **k: {
        "claude-fable-5-2": ("Fable 5.2 | GPT-6.1 Sol", "high"),
        "claude-opus-5": ("Opus 5 | GPT-6 Astra", "high"),
        "claude-sonnet-5": ("Sonnet 5.5 | GPT-6.1 Terra", "medium"),
        "claude-haiku-4-5": ("Haiku 5.5 | GPT-6 Luna", "low"),
    })
    cli._apply_model_labels(
        Profile(id="c", name="Codex", kind="codex", priority=1, automatic=True, enabled=True),
        [], host="127.0.0.1", port=4317, token="tok")

    # Live value, not the module literal (which says GPT-6.1 Terra for FABLE).
    assert os.environ["ANTHROPIC_DEFAULT_FABLE_MODEL_NAME"] == "Fable 5.2 | GPT-6.1 Sol"
    assert os.environ["ANTHROPIC_DEFAULT_FABLE_MODEL"] == "claude-fable-5-2"
    desc = os.environ["ANTHROPIC_DEFAULT_FABLE_MODEL_DESCRIPTION"]
    assert "Served by Codex" in desc and "high" in desc, desc


def test_parity_label_fetch_failure_falls_back_to_the_literals(monkeypatch):
    """A daemon that can't be reached must never leave the picker unlabelled —
    the offline literals stand in, in the same `<Claude> | <GPT>` shape."""
    from claude_unlimited import cli
    from claude_unlimited.config import Profile
    import os
    _clear(monkeypatch)

    monkeypatch.setattr(cli, "_fetch_parity_labels", lambda *a, **k: {})
    cli._apply_model_labels(
        Profile(id="c", name="Codex", kind="codex", priority=1, automatic=True, enabled=True),
        [], host="127.0.0.1", port=4317, token="tok")
    assert os.environ["ANTHROPIC_DEFAULT_SONNET_MODEL_NAME"] == "Sonnet 5.5 | GPT-6.1 Terra"


def test_rotated_all_claude_pool_keeps_native_labels(monkeypatch):
    """Nothing can be mislabelled when every account is Claude, so don't
    replace Claude Code's own labels with worse generic ones."""
    from claude_unlimited import cli
    import os
    _clear(monkeypatch)

    cli._apply_model_labels(None, [_p("oauth", "a"), _p("api", "b")])
    assert "ANTHROPIC_DEFAULT_SONNET_MODEL_NAME" not in os.environ


def test_status_line_shows_the_dashboard_url(monkeypatch, tmp_path):
    """The launch banner scrolls away; the status line keeps the Dashboard URL
    visible for the whole session."""
    from claude_unlimited import cli
    import json

    monkeypatch.setattr(cli.Path, "home", staticmethod(lambda: tmp_path))
    monkeypatch.chdir(tmp_path)

    args = cli._status_line_args(4317, [])
    assert args[0] == "--settings"
    settings = json.loads(args[1])
    assert settings["statusLine"]["type"] == "command"
    assert "127.0.0.1:4317" in settings["statusLine"]["command"]


def test_status_line_never_overrides_one_the_user_configured(monkeypatch, tmp_path):
    from claude_unlimited import cli
    import json

    (tmp_path / ".claude").mkdir()
    (tmp_path / ".claude" / "settings.json").write_text(
        json.dumps({"statusLine": {"type": "command", "command": "mine"}}))
    monkeypatch.setattr(cli.Path, "home", staticmethod(lambda: tmp_path))
    monkeypatch.chdir(tmp_path)

    assert cli._status_line_args(4317, []) == []


def test_status_line_yields_to_a_user_supplied_settings_flag(monkeypatch, tmp_path):
    from claude_unlimited import cli

    monkeypatch.setattr(cli.Path, "home", staticmethod(lambda: tmp_path))
    monkeypatch.chdir(tmp_path)

    assert cli._status_line_args(4317, ["--settings", "x.json"]) == []
    assert cli._status_line_args(4317, ["--settings=x.json"]) == []


def _routing_env(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://127.0.0.1:4317")
    monkeypatch.setenv("ANTHROPIC_AUTH_TOKEN", "sk-cu-local")


def test_a_project_pinning_the_base_url_is_overridden(monkeypatch, tmp_path):
    """Claude Code applies a settings file's env on top of the process
    environment, so a project that pins ANTHROPIC_BASE_URL sends every request
    somewhere else with whatever credential it carries — silently bypassing
    the pool the session was launched for."""
    import json as _json
    from claude_unlimited import cli

    (tmp_path / ".claude").mkdir()
    (tmp_path / ".claude" / "settings.json").write_text(_json.dumps({
        "env": {"ANTHROPIC_BASE_URL": "https://gateway.example", "ANTHROPIC_AUTH_TOKEN": "theirs"},
    }))
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(cli.Path, "home", staticmethod(lambda: tmp_path / "nohome"))
    _routing_env(monkeypatch)

    args = cli._status_line_args(4317, [])
    settings = _json.loads(args[args.index("--settings") + 1])
    assert settings["env"]["ANTHROPIC_BASE_URL"] == "http://127.0.0.1:4317"
    assert settings["env"]["ANTHROPIC_AUTH_TOKEN"] == "sk-cu-local"


def test_only_the_routing_keys_are_touched(monkeypatch, tmp_path):
    """A project's own env is its business — only the three keys that decide
    where traffic goes are reasserted."""
    import json as _json
    from claude_unlimited import cli

    (tmp_path / ".claude").mkdir()
    (tmp_path / ".claude" / "settings.json").write_text(_json.dumps({
        "env": {"ANTHROPIC_BASE_URL": "https://gateway.example", "MY_PROJECT_FLAG": "keep me"},
    }))
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(cli.Path, "home", staticmethod(lambda: tmp_path / "nohome"))
    _routing_env(monkeypatch)

    settings = _json.loads(cli._status_line_args(4317, [])[1])
    assert set(settings["env"]) == {"ANTHROPIC_BASE_URL", "ANTHROPIC_AUTH_TOKEN"}
    assert "MY_PROJECT_FLAG" not in settings["env"]


def test_a_project_without_routing_env_is_left_alone(monkeypatch, tmp_path):
    import json as _json
    from claude_unlimited import cli

    (tmp_path / ".claude").mkdir()
    (tmp_path / ".claude" / "settings.json").write_text(_json.dumps({"env": {"EDITOR": "vim"}}))
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(cli.Path, "home", staticmethod(lambda: tmp_path / "nohome"))
    _routing_env(monkeypatch)

    args = cli._status_line_args(4317, [])
    settings = _json.loads(args[1]) if args else {}
    assert "env" not in settings


def test_a_user_supplied_settings_flag_still_wins(monkeypatch, tmp_path):
    from claude_unlimited import cli
    _routing_env(monkeypatch)
    assert cli._status_line_args(4317, ["--settings", "mine.json"]) == []


def test_codex_picker_reflects_saved_list_and_unsets_removed_tiers(monkeypatch):
    """The /model labels come from the saved parity list: a row matches its
    tier by FAMILY (so a dated id still labels the slot), and a family the
    user removed leaves that tier's env unset rather than a stale default."""
    from claude_unlimited import cli
    from claude_unlimited.config import Profile
    import os
    _clear(monkeypatch)
    monkeypatch.setattr(cli, "_fetch_parity_labels", lambda *a, **k: {
        "claude-fable-5-2-20260101": ("Fable 5.2 | GPT-6.1 Sol", "high"),  # dated id
        "claude-opus-5": ("Opus 5 | GPT-6.1 Terra", "high"),
    })
    cli._apply_model_labels(
        Profile(id="c", name="Codex", kind="codex", priority=1, automatic=True, enabled=True),
        [], host="h", port=1, token="t")

    # Fable labelled via family match; the tier id stays the native default.
    assert os.environ["ANTHROPIC_DEFAULT_FABLE_MODEL"] == "claude-fable-5-2"
    assert os.environ["ANTHROPIC_DEFAULT_FABLE_MODEL_NAME"] == "Fable 5.2 | GPT-6.1 Sol"
    # The older opus-5 row labels the opus-5-5 slot, re-led with the id it sends.
    assert os.environ["ANTHROPIC_DEFAULT_OPUS_MODEL_NAME"] == "Opus 5.5 | GPT-6.1 Terra"
    # Sonnet and Haiku are not in the saved list -> left unset.
    assert "ANTHROPIC_DEFAULT_SONNET_MODEL_NAME" not in os.environ
    assert "ANTHROPIC_DEFAULT_HAIKU_MODEL_NAME" not in os.environ


def _fable_catalogue(*fable_ids):
    from claude_unlimited.model_catalogue import Catalogue, ModelInfo
    models = tuple(ModelInfo(id=mid, display_name=mid, supports_reasoning=True,
                             input_cost=None, output_cost=None, rank=i)
                   for i, mid in enumerate(fable_ids + ("claude-sonnet-5", "claude-haiku-4-5")))
    return Catalogue(anthropic=models, openai=())


def _fable_picker(monkeypatch, catalogue):
    from claude_unlimited import cli, model_catalogue
    import os
    _clear(monkeypatch)
    monkeypatch.setattr(model_catalogue, "current", lambda: catalogue)
    cli._apply_model_labels(_p("codex", "c"), [])
    return {k: v for k, v in os.environ.items() if k.startswith("ANTHROPIC_DEFAULT_")}


def test_fable_tier_stays_5_2_when_catalogue_only_has_5_2(monkeypatch):
    env = _fable_picker(monkeypatch, _fable_catalogue("claude-fable-5-2", "claude-fable-5-1"))
    assert env["ANTHROPIC_DEFAULT_FABLE_MODEL"] == "claude-fable-5-2"
    assert env["ANTHROPIC_DEFAULT_FABLE_MODEL_NAME"] == "Fable 5.2 | GPT-6.1 Sol"


def test_fable_tier_never_claims_older_than_native_5_2(monkeypatch):
    """A stale catalogue listing only 5.1 must not pull the slot below
    Claude Code's native Fable default (claude-fable-5-2), or the picker
    shows a duplicate native entry."""
    env = _fable_picker(monkeypatch, _fable_catalogue("claude-fable-5-1", "claude-fable-5"))
    assert env["ANTHROPIC_DEFAULT_FABLE_MODEL"] == "claude-fable-5-2"
    assert env["ANTHROPIC_DEFAULT_FABLE_MODEL_NAME"] == "Fable 5.2 | GPT-6.1 Sol"


def test_fable_tier_follows_5_5_in_the_catalogue_as_one_entry(monkeypatch):
    env = _fable_picker(monkeypatch, _fable_catalogue("claude-fable-5-5", "claude-fable-5-1"))
    assert env["ANTHROPIC_DEFAULT_FABLE_MODEL"] == "claude-fable-5-5"
    assert env["ANTHROPIC_DEFAULT_FABLE_MODEL_NAME"] == "Fable 5.5 | GPT-6.1 Sol"
    # One Fable slot only, and the other tiers keep their native defaults.
    assert [v for k, v in env.items() if k.endswith("_MODEL") and "fable" in v] == ["claude-fable-5-5"]
    assert env["ANTHROPIC_DEFAULT_SONNET_MODEL"] == "claude-sonnet-5-5"
    assert env["ANTHROPIC_DEFAULT_HAIKU_MODEL"] == "claude-haiku-5-5"


def test_fable_tier_falls_back_to_5_2_without_a_catalogue(monkeypatch):
    from claude_unlimited import model_catalogue
    monkeypatch.setattr(model_catalogue, "_load_offline", lambda: None)
    env = _fable_picker(monkeypatch, None)
    assert env["ANTHROPIC_DEFAULT_FABLE_MODEL"] == "claude-fable-5-2"


def test_fable_label_releads_when_slot_is_newer_than_saved_row(monkeypatch):
    """A saved parity row for Fable 5.1 with a catalogue whose newest Fable is
    5.5: the slot claims claude-fable-5-5, and its name must lead with 5.5."""
    from claude_unlimited import cli, model_catalogue
    import os
    _clear(monkeypatch)
    monkeypatch.setattr(model_catalogue, "current",
                        lambda: _fable_catalogue("claude-fable-5-5", "claude-fable-5-1"))
    monkeypatch.setattr(cli, "_fetch_parity_labels", lambda *a, **k: {
        "claude-fable-5-1": ("Fable 5.1 | GPT-6.1 Sol", "high"),
    })
    cli._apply_model_labels(_p("codex", "c"), [], host="h", port=1, token="t")
    assert os.environ["ANTHROPIC_DEFAULT_FABLE_MODEL"] == "claude-fable-5-5"
    assert os.environ["ANTHROPIC_DEFAULT_FABLE_MODEL_NAME"] == "Fable 5.5 | GPT-6.1 Sol"


def test_sonnet_and_haiku_labels_relead_when_saved_rows_are_older(monkeypatch):
    """Parity rows seeded from an older catalogue (claude-sonnet-5,
    claude-haiku-4-5) must not label the 5.5 ids the picker actually sends."""
    from claude_unlimited import cli, model_catalogue
    import os
    _clear(monkeypatch)
    monkeypatch.setattr(model_catalogue, "current",
                        lambda: _fable_catalogue("claude-fable-5-2"))
    monkeypatch.setattr(cli, "_fetch_parity_labels", lambda *a, **k: {
        "claude-fable-5-2": ("Fable 5.2 | GPT-6.1 Sol", "high"),
        "claude-sonnet-5": ("Sonnet 5 | GPT-6.1 Terra", "medium"),
        "claude-haiku-4-5-20251001": ("Haiku 4.5 | GPT-6 Luna", "low"),
    })
    cli._apply_model_labels(_p("codex", "c"), [], host="h", port=1, token="t")
    assert os.environ["ANTHROPIC_DEFAULT_SONNET_MODEL"] == "claude-sonnet-5-5"
    assert os.environ["ANTHROPIC_DEFAULT_SONNET_MODEL_NAME"] == "Sonnet 5.5 | GPT-6.1 Terra"
    assert os.environ["ANTHROPIC_DEFAULT_HAIKU_MODEL"] == "claude-haiku-5-5"
    assert os.environ["ANTHROPIC_DEFAULT_HAIKU_MODEL_NAME"] == "Haiku 5.5 | GPT-6 Luna"
    # Fable's own row matches its slot exactly: untouched.
    assert os.environ["ANTHROPIC_DEFAULT_FABLE_MODEL_NAME"] == "Fable 5.2 | GPT-6.1 Sol"


def test_tier_label_kept_when_a_saved_row_is_newer_than_the_slot():
    from claude_unlimited import cli
    live = {"claude-sonnet-6": ("Sonnet 6 | X", "medium")}
    assert cli._relead_newer_tier(live, "claude-sonnet-5-5", "claude-sonnet", "Sonnet 6 | X") == "Sonnet 6 | X"


def test_newest_fable_id_ranks_two_digit_minor_above_single_digit():
    from claude_unlimited import cli
    cat = _fable_catalogue("claude-fable-5-1", "claude-fable-5-9", "claude-fable-5-10", "claude-fable-5-5")
    assert cli._newest_fable_id(cat) == "claude-fable-5-10"


def test_restart_with_the_service_installed_first_stops_a_stray_daemon(monkeypatch):
    # A daemon `cu code` spawned while the service was down holds the port;
    # restarting only the service would leave it serving the old code.
    from claude_unlimited import cli

    calls = []
    monkeypatch.setattr(cli.daemon_installer, "status", lambda: {"installed": True})
    monkeypatch.setattr(cli, "_stop_running_daemon", lambda port: calls.append(("stop", port)))
    monkeypatch.setattr(cli.daemon_installer, "start", lambda: calls.append(("service-start",)))
    monkeypatch.setattr(cli, "_probe_health", lambda *a, **k: True)
    assert cli.restart(4317) == 0
    assert calls == [("stop", 4317), ("service-start",)]
