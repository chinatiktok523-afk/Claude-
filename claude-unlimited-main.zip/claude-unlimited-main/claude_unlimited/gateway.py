"""Ties Router + Observation + Proxy + secret_store into one handle() call.

This is the Proxy module's orchestration layer (see the implementation
review's module list) — the HTTP-server plumbing lives in daemon.py, the
pure decision/transform logic lives in router.py/observation.py/proxy.py,
and the real socket I/O lives in upstream.py. This file is what a real
request handler calls; it's kept separate from daemon.py's BaseHTTPRequestHandler
subclass so it can be tested with a fake `transport` callable instead of a
real HTTPS connection.

Safety rule, structural rather than by convention: this module NEVER forwards a single byte of the upstream
response body before deciding whether to retry on quota-exhaustion. Status
and headers arrive first (see upstream.send's use of http.client, which
reads the header block before any body read); the retry decision is made
right there, before body_chunks is ever iterated. Once the caller starts
draining body_chunks, that response is committed — Gateway will not retry
underneath it.
"""

from __future__ import annotations

import http.client
import itertools
import json
import threading
import time
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from typing import Callable, Iterator, Optional
from urllib.parse import urlparse

from . import activity, codex_cli, eco, refresh_backoff, gpt_windows, media_budget, speech, connectors, notifications, oauth_credential, oauth_login, openai_bridge, openai_credential, openai_models, openai_observation, openai_translate, project_attribution, project_usage, runtime_state, secret_store, usage_history, usage_probe, usage_tracking
from . import profiles as profile_repo
from .config import Pool, Profile, load_pool
from .observation import AuthInvalid, BudgetUnavailable, ModelWindow, ProviderUnavailable, QuotaExhausted, ShortRateLimit, Unknown, UsageSnapshot, classify
from .proxy import (REQUEST_TOO_LARGE_STATUS, RequestTooLarge, build_upstream_request, check_request_size,
                    filter_response_headers, max_request_bytes, request_model, rewrite_model, retry_without_rejected_thinking)
from .router import (
    PoolSnapshot,
    ProfileRuntime,
    ProfileState,
    RequestFit,
    RoutingDecision,
    choose,
    choose_for_new_branch,
    fable_spent,
    fits,
    must_leave,
    observe,
    record_credits,
    recover_expired_cooldowns,
)
from .upstream import UpstreamResponse
from .upstream import send as real_send

MAX_ROTATION_ATTEMPTS = 4  # minimum bound; larger configured pools get one pass

# How long an idle branch keeps its account pin. A pin is only a routing
# preference, so outliving Anthropic's prompt cache costs nothing; expiring too
# eagerly would scatter a slow-but-live branch across accounts. Evicted lazily
# at request boundaries (no background task), like session_tokens' prune-on-touch.
BRANCH_PIN_TTL_SECONDS = 3600.0
# Hard ceiling so a long-lived daemon can't accumulate pins without bound;
# oldest-touched is evicted first.
BRANCH_PIN_CAP = 512


def _pin_clock() -> float:
    """The branch-pin store's clock — its own seam, so a test can age pins
    without replacing time.monotonic for every thread in the process."""
    return time.monotonic()


# An agent moved off an unavailable account is logged every time, but the
# desktop notification fires at most this often per source account: one busy
# session can move many agents off the same account within seconds.
BRANCH_MOVE_NOTIFY_INTERVAL_SECONDS = 900.0
# Decision reasons that mean "this request was routed for ONE branch, not by
# the shared rotation pointer". Such a request must never move that pointer or
# fire a "Rotated" notification — the same discipline an explicit --profile pin
# already follows, for the same reason: other concurrent sessions and branches
# are relying on normal rotation at the same moment.
_BRANCH_ROUTED_REASONS = frozenset({"branch_pinned", "subagent_forced", "branch_assigned"})


def _client_label(headers: dict) -> str:
    """A short name for whoever sent this request, for the Activity log.

    Exists because "is the desktop app actually routed through the pool?" was
    only answerable by correlating timestamps by hand. The Claude Code CLI and
    the desktop app both identify themselves in User-Agent; anything else is
    reported as-is, truncated."""
    ua = ""
    for key, value in (headers or {}).items():
        if key.lower() == "user-agent":
            ua = str(value)
            break
    if not ua:
        return "unknown"
    return ua[:60]


def _filter_openai_headers(headers: dict[str, str]) -> dict[str, str]:
    """The codex-kind analogue of proxy.filter_response_headers — restricts
    an OpenAI backend response's headers to openai_observation.py's own
    allowlist before classify() ever sees them, same contract as the
    Anthropic side."""
    lower = {k.lower(): v for k, v in headers.items()}
    return {k: lower[k] for k in openai_observation.ALLOWED_HEADERS if k in lower}

# A Profile is warned about an approaching threshold once per crossing, not
# once per request — this in-memory set is cleared for a Profile the moment
# it leaves ELIGIBLE (rotated/exhausted) or comes back from a reset, so the
# next approach gets its own warning instead of staying silent forever.
_QUOTA_RESET_SOURCE_STATES = (ProfileState.COOLDOWN, ProfileState.EXHAUSTED, ProfileState.DRAINING)
APPROACHING_THRESHOLD_BAND = 5.0  # percentage points below switch_threshold that counts as "approaching"

# Status codes plausibly meaning "this specific model isn't usable with this
# key" for an API-kind Profile — 400 (invalid_request_error, e.g. "model:
# X not found"), 403 (permission_error, key not scoped for this model —
# see observation.py's classify()), 404 (not_found_error). Never touches
# OAuth Profiles or any other status: this is specifically the
# default_model fallback (see Gateway._maybe_retry_with_default_model).
_MODEL_FALLBACK_STATUS_CODES = (400, 403, 404)
# An error body is a few hundred bytes; the cap only stops a misbehaving
# upstream streaming megabytes into memory before the answer goes back.
_MAX_ERROR_BODY_PEEK = 64 * 1024
# Wording that marks a 400 as "the input is too big", not "unknown model".
# Anthropic says "prompt is too long"; local servers (MLX, llama.cpp, vLLM)
# say "exceeds max context window" / "maximum context length".
_CONTEXT_OVERFLOW_MARKERS = (b"too long", b"context window", b"context length",
                             b"maximum context", b"exceeds max", b"exceeds the context")
# Wording that marks a 400 as "no such model". The word "model" alone is not
# enough: "model: field required" or "max_tokens too large for this model"
# are malformed requests, and remembering them would move later requests
# off a model the endpoint serves fine.
_MODEL_REFUSAL_MARKERS = (b"not found", b"unknown model", b"invalid model", b"does not exist",
                          b"not supported", b"no such model", b"unsupported model",
                          b"not available", b"model_not_found")


def _peek_error_body(resp: "UpstreamResponse") -> tuple[bytes, "UpstreamResponse"]:
    """Reads an error response's body and hands back an equivalent response
    that will still yield those same bytes, so the caller can inspect it and
    still forward it unchanged."""
    raw = bytearray()
    chunks = iter(resp.body_chunks)
    for chunk in chunks:
        raw.extend(chunk)
        if len(raw) >= _MAX_ERROR_BODY_PEEK:
            break
    data = bytes(raw)
    # Past the cap the rest is still forwarded, just not inspected.
    rest = itertools.chain([data] if data else [], chunks)
    return data, replace(resp, body_chunks=rest)


def _is_model_refusal(status: int, error_body: bytes) -> bool:
    """Whether this error means "this endpoint does not serve that model"."""
    text = error_body.lower()
    if any(marker in text for marker in _CONTEXT_OVERFLOW_MARKERS):
        return False
    if status in (403, 404):
        # 404 "no such model", 403 "this key may not use that model". Neither
        # ever means the input was too big.
        return True
    # A 400 is also every malformed-request error; only one that names the
    # model AND says it is missing is about the model.
    return b"model" in text and any(marker in text for marker in _MODEL_REFUSAL_MARKERS)


def _force_model_body(profile: "Profile", body: bytes) -> Optional[bytes]:
    """An api Profile with force_model sends that model on every request,
    whatever the client asked for. None when nothing is forced, or the body
    has no model to replace (token counting, other side calls)."""
    if profile.kind != "api" or not getattr(profile, "force_model", None):
        return None
    requested = request_model(body)
    if requested is None or requested == profile.force_model:
        return None
    return rewrite_model(body, profile.force_model)


# Claude Code opens every system prompt with an attribution block,
# "x-anthropic-billing-header: ... cch=<hash>; ...", whose hash changes on
# every request. Anthropic strips it before inference. A third-party
# Anthropic-compatible endpoint (OpenRouter, a local model server) feeds it to
# the model as the first tokens of the prompt, so no two requests share a
# prefix and prompt caching never hits: every turn is billed as fresh input.
_BILLING_HEADER_PREFIX = "x-anthropic-billing-header:"


def _strip_billing_header_body(profile: "Profile", body: bytes) -> Optional[bytes]:
    """The body without Claude Code's per-request attribution block, for an
    api Profile that does not point at Anthropic. None when there is nothing
    to strip, so Anthropic-bound and oauth traffic are never touched."""
    if profile.kind != "api" or not profile.base_url:
        return None
    host = (urlparse(profile.base_url).hostname or "").lower()
    if host == "anthropic.com" or host.endswith(".anthropic.com"):
        return None
    if _BILLING_HEADER_PREFIX.encode() not in body:
        return None
    try:
        parsed = json.loads(body)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None
    if not isinstance(parsed, dict):
        return None
    system = parsed.get("system")
    if isinstance(system, list):
        kept = [block for block in system
                if not (isinstance(block, dict) and block.get("type") == "text"
                        and str(block.get("text", "")).startswith(_BILLING_HEADER_PREFIX))]
        if len(kept) == len(system):
            return None
        parsed["system"] = kept
    elif isinstance(system, str) and system.startswith(_BILLING_HEADER_PREFIX):
        rest = system.split("\n", 1)[1] if "\n" in system else ""
        if rest:
            parsed["system"] = rest
        else:
            parsed.pop("system")
    else:
        return None
    return json.dumps(parsed).encode("utf-8")


def _restorable_usage_fields(persisted: Optional[dict], now: datetime) -> dict:
    """Turns one profile's entry from runtime_state.load() into
    ProfileRuntime kwargs — only the usage-number fields, never state.
    A window whose resets_at has already passed isn't restored at all
    (showing a stale percentage past its own reset would be actively
    wrong); everything else defensively no-ops on missing/malformed data
    rather than raising — this must never break daemon startup."""
    if not persisted:
        return {}

    def _parse(iso: object) -> Optional[datetime]:
        if not isinstance(iso, str):
            return None
        try:
            parsed = datetime.fromisoformat(iso)
        except ValueError:
            return None
        # A naive timestamp compared with the aware `now` raises TypeError,
        # and this runs at startup. Everything we write is UTC.
        return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=timezone.utc)

    fields: dict = {}
    resets_at = _parse(persisted.get("resets_at"))
    if resets_at is not None and resets_at > now and isinstance(persisted.get("last_usage_percent"), (int, float)):
        fields["last_usage_percent"] = persisted["last_usage_percent"]
        fields["resets_at"] = resets_at
    resets_at_7d = _parse(persisted.get("resets_at_7d"))
    if resets_at_7d is not None and resets_at_7d > now and isinstance(persisted.get("last_usage_percent_7d"), (int, float)):
        fields["last_usage_percent_7d"] = persisted["last_usage_percent_7d"]
        fields["resets_at_7d"] = resets_at_7d
    # Per-model windows, same rule: one past its own reset is dropped.
    windows = []
    for row in persisted.get("model_usage") or ():
        if not isinstance(row, dict) or not isinstance(row.get("name"), str) \
                or isinstance(row.get("percent"), bool) or not isinstance(row.get("percent"), (int, float)):
            continue
        window_reset = _parse(row.get("resets_at"))
        if window_reset is not None and window_reset <= now:
            continue
        windows.append(ModelWindow(name=row["name"], percent=float(row["percent"]),
                                   resets_at=window_reset, active=row.get("active") is True))
    if windows:
        fields["model_usage"] = tuple(windows)
    # Prepaid credits (issue #6). No expiry rule: unlike a usage window, a
    # balance does not refill on a clock, so the last known figure stays the
    # best answer until the backend reports a new one. Restoring it matters —
    # without it a restart shows "credits: unknown" on an account the pool may
    # be about to spend money from.
    if isinstance(persisted.get("credits_has"), bool):
        fields["credits_has"] = persisted["credits_has"]
    balance = persisted.get("credits_balance")
    if isinstance(balance, (int, float)) and not isinstance(balance, bool):
        fields["credits_balance"] = float(balance)
    return fields



def _replace_runtime(rt: ProfileRuntime, **changes) -> ProfileRuntime:
    from dataclasses import replace
    return replace(rt, **changes)


def _eco_mode_of(stats) -> Optional[str]:
    """Which tier produced a saving — a number without its tier cannot be
    compared across a settings change."""
    return getattr(stats, "tier", None)


def _eco_compact(body: bytes, tier: str) -> tuple[bytes, "eco.CompactionStats"]:
    """Compact tool output before the request leaves the daemon.

    Fails open at every step (invariant 5): a body that will not parse, a
    filter that raises, or a result that will not re-serialise all return the
    ORIGINAL bytes. ECO must never be the reason a request fails.

    Called once per handle(), not per rotation attempt: a failover re-sends
    from the original body, and compacting an already-compacted body is how
    markers stack up.
    """
    if tier == "off" or not body:
        return body, eco.CompactionStats()
    try:
        parsed = json.loads(body)
    except (ValueError, TypeError):
        return body, eco.CompactionStats()
    try:
        new_body, stats = eco.compact_request(parsed, tier)
    except Exception:
        return body, eco.CompactionStats()
    if not stats.touched:
        return body, stats
    object.__setattr__(stats, "tier", tier)
    try:
        # Compact separators and real UTF-8: the defaults inflate non-ASCII to
        # \uXXXX escapes and add a byte per key/element, which made the body
        # grow for any conversation with diacritics or emoji.
        encoded = json.dumps(new_body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    except (TypeError, ValueError):
        return body, eco.CompactionStats()
    if len(encoded) >= len(body):
        # Invariant 3 at the WIRE level, not just per tool result: if the
        # re-serialised body is not smaller, send the original and claim
        # nothing. A reported saving must be a real one.
        return body, eco.CompactionStats()
    return encoded, stats


def _speech_apply(body: bytes, stats: "eco.CompactionStats", level: str) -> tuple[bytes, "eco.CompactionStats"]:
    """Primitive speech: add its instruction to an agent turn's system prompt.

    Fails open exactly like ECO — a body that will not parse or re-serialise
    goes out untouched. The level rides on the stats object, like ECO's tier,
    so the usage row records which replies were written under it."""
    if level == "off" or not body:
        return body, stats
    try:
        parsed = json.loads(body)
        new_body, added = speech.apply(parsed, level)
        if not added:
            return body, stats
        encoded = json.dumps(new_body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    except (ValueError, TypeError):
        return body, stats
    # CompactionStats() is a shared-looking default; never tag that instance.
    if not stats.touched:
        stats = eco.CompactionStats()
    object.__setattr__(stats, "speech", level)
    return encoded, stats


def _drop_empty_text_blocks(body: bytes) -> bytes:
    """Remove empty text blocks from a request before it is forwarded.

    Anthropic rejects a request carrying one outright — `400 messages: text
    content blocks must be non-empty` — and a client re-sends its whole
    conversation every turn, so ONE empty block recorded in a session's
    history breaks every later request in that session, on every account.
    That is not a hypothetical: the Codex bridge used to emit one whenever a
    reply went straight to a tool call, and the sessions it wrote could not be
    continued afterwards even though nothing was wrong with the account.

    Fixing the producer cannot repair a transcript already on disk, so the
    request path drops them here. A message left with no content at all is
    dropped with them — it can only have been an empty block on its own,
    never a tool_use or tool_result, so nothing that must stay paired is
    touched. Fails open like every other rewrite: a body that will not parse
    goes out exactly as it came in.
    """
    if not body:
        return body
    try:
        parsed = json.loads(body)
    except (ValueError, TypeError):
        return body
    if not isinstance(parsed, dict):
        return body

    def keep(block) -> bool:
        return not (isinstance(block, dict) and block.get("type") == "text"
                    and not (block.get("text") or "").strip())

    changed = False
    messages = parsed.get("messages")
    if isinstance(messages, list):
        kept_messages = []
        for message in messages:
            content = message.get("content") if isinstance(message, dict) else None
            if isinstance(content, list):
                kept = [b for b in content if keep(b)]
                if len(kept) != len(content):
                    changed = True
                    if not kept:
                        continue  # the whole message was one empty block
                    message = {**message, "content": kept}
            kept_messages.append(message)
        if changed:
            parsed["messages"] = kept_messages

    # The system prompt is rejected the same way, and is rebuilt every turn by
    # ECO and primitive speech, so it can pick one up too.
    system = parsed.get("system")
    if isinstance(system, list):
        kept_system = [b for b in system if keep(b)]
        if len(kept_system) != len(system):
            changed = True
            parsed["system"] = kept_system

    if not changed:
        return body
    try:
        return json.dumps(parsed, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    except (ValueError, TypeError):
        return body


def _codex_5h_percent(headers: dict) -> Optional[float]:
    """The primary (5h) window percentage a Codex response reported."""
    value = {k.lower(): v for k, v in (headers or {}).items()}.get("x-codex-primary-used-percent")
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _speech_level_of(stats) -> Optional[str]:
    return getattr(stats, "speech", None)


def _parsed_request(body: bytes) -> Optional[dict]:
    """The inbound Anthropic request body as a dict, or None when there is
    nothing usable. A conversation body can be megabytes, so callers share
    ONE parse rather than each doing their own."""
    if not body:
        return None
    try:
        parsed = json.loads(body)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None
    return parsed if isinstance(parsed, dict) else None


def _requested_model(parsed: Optional[dict]) -> Optional[str]:
    """The model the CLIENT asked for. A codex-kind Profile answers with the
    OpenAI model that actually ran (gpt-6-astra), which on its own cannot be
    told apart from a request that asked for Opus — so this is the only
    record of what the mapping started from."""
    model = (parsed or {}).get("model")
    return model if isinstance(model, str) else None


def _client_wants_streaming(parsed: Optional[dict]) -> bool:
    """Whether the inbound Anthropic request asked for an SSE response.

    Follows the Anthropic API: streaming only when `stream` is true. A body
    WITHOUT the field is a non-streaming call — that is how the Anthropic SDK
    sends `messages.create()` when streaming is not requested, and it is
    exactly how Claude Code's auto-mode safety classifier calls. Treating an
    absent field as streaming sent that classifier an SSE body it could not
    parse, and every Edit/Bash in auto mode on a Codex account failed with
    "claude-sonnet-5 is temporarily unavailable". Only an unparsable body is
    still treated as streaming, so a malformed request never buffers a whole
    response in memory."""
    if not parsed:
        return True
    return parsed.get("stream") is True


def _restorable_state_fields(persisted: Optional[dict], now: datetime) -> dict:
    """State worth carrying across a restart, so the Dashboard looks the same
    the moment the daemon comes back rather than claiming every Profile is
    healthy until something proves otherwise.

    Only states that are still true survive:

      * AUTH_INVALID persists. A rejected credential does not repair itself by
        restarting, and it clears the moment the credential is actually
        replaced (see _sync_snapshot's credential_refreshed branch).
      * COOLDOWN persists only while its own deadline is still in the future.
      * Everything else is re-derived. ELIGIBLE/DRAINING follow from the usage
        numbers that are restored alongside, EXHAUSTED from a token budget
        that is recomputed anyway, and DISABLED from configuration.

    Never raises: a malformed or missing entry means "nothing to restore",
    exactly like a first run."""
    if not persisted:
        return {}
    fields: dict = {}
    for label_key in ("window_label", "window_label_7d"):
        value = persisted.get(label_key)
        if isinstance(value, str) and value:
            fields[label_key] = value

    state = persisted.get("state")
    if state == ProfileState.AUTH_INVALID.value:
        fields["state"] = ProfileState.AUTH_INVALID
    elif state == ProfileState.COOLDOWN.value:
        raw = persisted.get("cooldown_until")
        try:
            deadline = datetime.fromisoformat(raw) if isinstance(raw, str) else None
        except ValueError:
            deadline = None
        if deadline is not None and deadline > now:
            fields["state"] = ProfileState.COOLDOWN
            fields["cooldown_until"] = deadline
            fields["budget_unavailable"] = persisted.get("budget_unavailable") is True
    return fields


@dataclass
class BranchPin:
    """Which account one conversation branch is bound to, and when it was last
    used (for TTL/LRU eviction). agent_id/parent_agent_id are carried for the
    Dashboard's session tree only — routing keys on the map key, not these."""

    profile_id: str
    last_touch: float  # time.monotonic()
    created_at: float
    agent_id: str
    parent_agent_id: Optional[str] = None
    distributed: bool = False  # placed by distribute mode (choose_for_new_branch)


def _blocked_models_for(profile: Profile, model_usage, settings, now: datetime) -> frozenset:
    """Which Claude models this codex Profile cannot serve right now.

    OpenAI reports availability keyed by the GPT model id (`gpt-6-astra`),
    while routing is asked about a CLAUDE id. Resolving one to the other needs
    the parity list and the model catalogue — file I/O — so it happens here,
    where both are already in hand, and router.py gets a plain set.

    Only the models the pool actually advertises are resolved: the in-force
    parity rows ARE the set Claude Code's picker offers for a codex-served
    session, so they are the ids that can arrive. A model outside that set
    falls through as unblocked, which is the safe direction — the provider's
    own error is better than idling an account on a guess.

    Returns an empty set for anything that is not a codex Profile, and for a
    codex Profile whose backend reported nothing."""
    if profile.kind != "codex" or not model_usage:
        return frozenset()
    unavailable = set()
    for window in model_usage:
        if window.percent < 100:
            continue
        # A bucket past its own available_at is stale, not blocking — the same
        # rule fable_spent() applies to Anthropic's windows.
        resets_at = getattr(window, "resets_at", None)
        if resets_at is not None and now >= resets_at:
            continue
        unavailable.add(window.name.strip().lower())
    if not unavailable:
        return frozenset()

    from .model_catalogue import base_id
    from . import openai_models

    blocked = set()
    try:
        rows = openai_models.normalize_parity(getattr(settings, "model_parity", None))
    except Exception:
        return frozenset()   # a broken parity list must not block every model
    for row in rows:
        claude_model = row.get("claude_model")
        if not isinstance(claude_model, str) or not claude_model:
            continue
        try:
            target = openai_models.map_model(
                claude_model,
                override_model=profile.codex_model,
                override_reasoning_effort=profile.codex_reasoning_effort,
                parity=rows)
        except Exception:
            continue
        if target.model and target.model.strip().lower() in unavailable:
            blocked.add(base_id(claude_model).lower())
    return frozenset(blocked)


@dataclass(frozen=True)
class RequestGuard:
    """The per-request capacity guard's verdict for ONE request (docs/adr
    0009): the pure `fit` router.py filters on, plus what the gateway needs
    to explain it — each codex Profile's resolved window for this request's
    model. None (see _request_guard) means the body is under the byte floor
    and nothing was sized."""
    fit: RequestFit
    windows: dict  # profile_id -> gpt_windows.WindowInfo, codex Profiles only


def _request_guard(body: bytes, parsed: Optional[dict], pool: Pool) -> Optional[RequestGuard]:
    """Which codex Profiles cannot hold this conversation.

    Stage 1 is free: a body under gpt_windows.CERTAINLY_FITS_BYTES cannot
    exceed any codex budget, so the common case parses nothing and returns
    None — which is also the answer for a pool with no codex Profile, and
    for anything that is not a /v1/messages turn (the caller's check).
    Stage 2 reuses the shared parse when the caller already has one, and
    parses otherwise; an unparsable body is sized from its bytes alone,
    which only ever over-estimates and so only ever excludes codex.

    Never raises, and never puts an oauth/api Profile in the set: Claude Code
    sizes those windows itself. Any failure here degrades to "not sized" —
    today's behaviour — rather than blocking Anthropic traffic."""
    if len(body) < gpt_windows.CERTAINLY_FITS_BYTES:
        return None
    codex = [p for p in pool.profiles if p.kind == "codex" and p.enabled]
    if not codex:
        return None
    try:
        if parsed is None:
            parsed = _parsed_request(body)
        estimate = gpt_windows.estimate_input_tokens(body, parsed)
        requested = _requested_model(parsed)
        try:
            rows = openai_models.normalize_parity(getattr(pool.settings, "model_parity", None))
        except Exception:
            rows = None
        windows: dict = {}
        over = set()
        for profile in codex:
            try:
                target = openai_models.map_model(
                    requested, override_model=profile.codex_model,
                    override_reasoning_effort=profile.codex_reasoning_effort, parity=rows)
                model = target.model
            except Exception:
                model = profile.codex_model  # unknown → assumed at the floor
            info = gpt_windows.window_for(model, getattr(profile, "auth_mode", None),
                                          getattr(profile, "base_url", None))
            windows[profile.id] = info
            if estimate > info.budget:
                over.add(profile.id)
        return RequestGuard(fit=RequestFit(estimated_tokens=estimate, over_capacity=frozenset(over)),
                            windows=windows)
    except Exception:
        return None


def _leave_on_fable_limit(p: Profile, settings) -> bool:
    """The RESOLVED "leave when Fable is spent" switch for this Profile: its
    own flag, or the pool-wide override that makes every Profile behave as if
    its flag were on. Resolved here, once per sync, so router.py never has to
    look at Settings. Harmless on an api Profile — it never reports a Fable
    bucket, so fable_spent() is always False for it."""
    return bool(getattr(p, "leave_on_fable_limit", False)
                or getattr(settings, "fable_limit_all_profiles", False))


def _may_spend_credits(p: Profile, settings) -> bool:
    """Whether this Profile is allowed to keep serving on prepaid credits.
    Codex-only: no other backend reports a credit balance, and mirroring the
    setting onto an oauth or api Profile would let a future change read a
    permission that can never legitimately apply to it."""
    return bool(p.kind == "codex" and getattr(settings, "codex_spend_credits", False))


MESSAGE_ALL_EXHAUSTED = "Claude Unlimited — all profiles are out of capacity."

def _out_of_capacity(rt) -> bool:
    """Whether this Profile has no capacity left, as opposed to being
    unusable for some other reason.

    EXHAUSTED and DRAINING say so outright. A COOLDOWN does not: it covers
    both a provider rate-limit and a provider that could not be reached at
    all, and "we could not connect" must never be reported to the user as
    "you are out of quota". The account's own usage is what tells them apart —
    a cooldown on an account sitting at its switch threshold is its quota
    running out; a cooldown at 3% is the network.
    """
    if rt.state in (ProfileState.EXHAUSTED, ProfileState.DRAINING):
        return True
    return (rt.state == ProfileState.COOLDOWN
            and rt.last_usage_percent is not None
            and rt.last_usage_percent >= rt.switch_threshold)


def _capacity_exhaustion(snapshot, pool) -> tuple[bool, Optional[datetime]]:
    """(every usable Profile is out of capacity, when the first one returns).

    "Usable" means enabled: a Profile the user switched off is not part of the
    pool's capacity, so a pool of one enabled account that hits its limit is
    exhausted even with three disabled ones beside it.
    """
    enabled = {p.id for p in pool.profiles if p.enabled}
    runtimes = [rt for rt in snapshot.profiles if rt.profile_id in enabled]
    if not runtimes or not all(_out_of_capacity(rt) for rt in runtimes):
        return False, None
    deadlines = [d for rt in runtimes
                 for d in (rt.resets_at, rt.cooldown_until) if d is not None]
    return True, min(deadlines) if deadlines else None


def _exhaustion_message(resets_at: Optional[datetime]) -> str:
    if resets_at is None:
        return MESSAGE_ALL_EXHAUSTED
    return f"{MESSAGE_ALL_EXHAUSTED} The first one resets at {resets_at.astimezone():%H:%M}."


@dataclass(frozen=True)
class GatewayResult:
    status: int
    headers: dict
    body_chunks: Optional[Iterator[bytes]]
    profile_id: Optional[str]
    error: Optional[str] = None
    # The sentence to show the user, when the gateway knows something more
    # specific than the error code's stock wording (e.g. when capacity comes
    # back). None means "use the stock message for `error`".
    error_detail: Optional[str] = None


class Gateway:
    """Holds the live Rotation state for the running daemon process. One
    instance per daemon.

    _USED_NOW_GRACE_SECONDS: how long a Profile keeps showing as "Used now"
    on the Dashboard after its last request finished — see in_flight_ids()'s
    docstring for why this exists at all (a quick call can complete faster
    than the Dashboard polls). Deliberately session-length, not
    request-length: the intent is "this Profile is what an active session
    is currently using," not "a request literally completed within the
    last few seconds" — a real gap between individual API calls in an
    ongoing conversation (thinking time, a long tool call, someone reading
    a response) is normal and must not flicker the indicator off. It
    clears sooner than this if a real rotation switch moves the shared
    pointer away from this Profile first — see handle()'s
    `self._last_active.pop(previous_profile_id, None)`.

    Rotation STATE itself (ELIGIBLE/DRAINING/EXHAUSTED/COOLDOWN/AUTH_INVALID)
    is intentionally NOT persisted across a restart — see router.py's module
    docstring: no claimed per-session affinity, request-boundary global Pool
    state only, and every enabled Profile genuinely deserves a fresh try
    after a restart, same as it always has. What IS persisted (via
    runtime_state.py) is just the last-observed usage numbers and which
    Profile was current — display-only data the Dashboard would otherwise
    show as a blank "not yet observed" wall after every restart/update/
    service bounce, even though the real quota window hasn't actually
    reset. A number whose reset time has already passed by load time is
    dropped, not restored — see _sync_snapshot()."""

    _USED_NOW_GRACE_SECONDS = 900.0  # 15 minutes — see the class docstring
    # Upper bound on how long a single in-flight request can keep a Profile
    # "Used now". A real streaming request finishes in seconds to a couple of
    # minutes; anything still marked in-flight past this is a leaked/hung slot
    # (a client that walked away, an upstream that never closed), so stop
    # counting it rather than pinning the indicator — and the idle check — on
    # forever. Generous enough never to drop a genuinely-live request.
    _IN_FLIGHT_MAX_SECONDS = 300.0  # 5 minutes
    _REFRESH_CHECK_COOLDOWN_SECONDS = 60.0
    # Recovery attempts on a Profile that is ALREADY needs-re-auth get their
    # own, much longer interval.
    #
    # They used to share the 60s one, which meant a stuck account asked the
    # token endpoint to refresh a dead credential 1,440 times a day. That is
    # what earned the 429s, and it fed itself: rate limited -> still
    # AUTH_INVALID -> ask again in 60s. A preventive refresh (token genuinely
    # near expiry) stays responsive; a recovery poll does not need to be, and
    # ten minutes still self-heals long before anyone notices.
    _REAUTH_RECOVERY_COOLDOWN_SECONDS = 600.0
    # A 429 from the OAuth token endpoint means back off hard. Retrying a
    # rate-limited endpoint every 60s only re-triggers the same limiter and
    # never lets it clear.
    _RATE_LIMIT_BACKOFF_SECONDS = 900.0
    # Each further consecutive rate-limited refresh doubles the wait, up to
    # this ceiling. A flat interval never lets a persistently rate-limited
    # endpoint recover: it just keeps arriving at the same rate forever.
    _RATE_LIMIT_BACKOFF_CEILING_SECONDS = refresh_backoff.SLOW_CEILING_SECONDS
    # After this many consecutive rate-limited refreshes, say so once — the
    # endpoint has been refusing for hours and a re-authentication is probably
    # needed. It does NOT stop trying.
    #
    # It used to. That was a deadlock: the streak is only cleared by a
    # SUCCESSFUL refresh, and the give-up check returned before ever attempting
    # one, so nothing could clear it and no retry ever happened. The only exits
    # were a manual re-auth or a daemon restart — which meant a daemon left
    # running, exactly as intended, was the case that could never recover. An
    # account sat given-up for seven hours and then expired.
    #
    # The escalating backoff is the real protection: at the ceiling this is at
    # most four attempts a day, which is not noise against anyone's limiter.
    _RATE_LIMITED_REFRESHES_BEFORE_WARNING = 6

    def __init__(self, transport: Callable = real_send):
        self._lock = threading.Lock()
        self._runtime: dict[str, ProfileRuntime] = {}
        self._current_profile_id: Optional[str] = None
        self._transport = transport
        self._warned_approaching: set[str] = set()
        # True once "everything is out of capacity" has been announced, so the
        # next thousand rejected requests do not each write an Activity line
        # and fire a notification. Cleared the moment any Profile can serve
        # again (see _note_capacity_back).
        self._exhaustion_announced = False
        # Profile ids with a request genuinely in flight right now — a
        # request is only ever added here once it's actually being served
        # (transport call started) and removed once that Profile's response
        # is fully drained or the client disconnects (see
        # _wrap_with_in_flight_clear). Backs the Dashboard's "Used now"
        # indicator; unlike current_profile_id (one shared rotation
        # pointer), more than one Profile can legitimately be in here at
        # once — e.g. two concurrent `claude-unlimited code --profile`
        # terminals pinned to different Profiles.
        self._in_flight: set[str] = set()
        # Per-branch account pins: {(lineage_session_id, agent_id): BranchPin}.
        # A "branch" is one conversation thread — a session's main agent, or
        # one of its subagents (project_attribution.branch_key). Pinning keeps
        # a branch on the account that already holds its prompt cache, while
        # DIFFERENT branches of the same session can sit on different accounts
        # (that's the point: several subscriptions serving one session at once,
        # each with a warm cache). Lives here rather than in router.py because
        # it is mutable cross-request state with a clock and a lock — exactly
        # what that module's purity contract excludes.
        self._branch_pins: dict[tuple, BranchPin] = {}
        # The `codex` CLI path (handle_codex_cli) keeps its own routing state,
        # never the shared pointer above: a codex session changing accounts
        # must not move Claude Code's rotation, nor the other way round. Both
        # read the same usage, so an account one of them used up is skipped by
        # the other.
        #   pins: codex thread id -> the account serving that conversation.
        #   current: where a conversation with no pin starts.
        self._codex_cli_pins: dict[str, str] = {}
        self._codex_cli_current_id: Optional[str] = None
        self._branch_move_notified_at: dict[str, float] = {}
        # Epoch seconds of each Profile's last usage reading, from any source
        # (real traffic or usage_probe) — so a background check can skip an
        # account real traffic already refreshed.
        self._usage_observed_at: dict[str, float] = {}
        # Monotonic time each Profile's current in-flight streak began. A
        # request that never drains — a client that abandons the stream, or an
        # upstream connection that hangs open — would otherwise leave its
        # Profile in _in_flight forever, pinning "Used now" and wedging the
        # idle check (both symptoms actually observed: a Profile stuck "Used
        # now" 20+ minutes after its last request, long past the grace window).
        # in_flight_ids() ignores an entry older than _IN_FLIGHT_MAX_SECONDS so
        # such a slot self-heals; no legitimate single request runs that long.
        # "Take over" — held until another Take Over or until the Profile
        # stops being ELIGIBLE (see _manual_choice).
        self._manual_profile_id: Optional[str] = None
        # One credential-check worker at a time (see _schedule_credential_checks).
        self._credential_check_running = False
        self._in_flight_since: dict[str, float] = {}
        # Profiles whose spent Fable week has already been noted in Activity
        # for a pin that is being honoured anyway (--profile, Take over,
        # forced-in-subagents) or for a pool with nowhere else to go. A pinned
        # session retries on every turn; one line per account per spent week
        # is information, one per request is a flood. Cleared the moment the
        # account is no longer spent, so the next week gets its own line.
        self._fable_limit_noted: set = set()
        # GPT ids the capacity guard has already said it is ASSUMING a window
        # for (not in gpt_windows' table). One Activity line per id per
        # daemon run; the preview shows the assumption for as long as it holds.
        self._window_assumed_noted: set = set()
        # When the guard last answered "prompt is too long" for a given
        # session/pin key -> monotonic time. Claude Code compacts and retries
        # on that answer, so one Activity line per key per interval is the
        # information; one per request would be the flood the exhaustion
        # announcement above already avoids.
        self._capacity_noted_at: dict = {}
        # Profiles that took a 429 their ACCOUNT-level windows cannot explain,
        # so a per-model limit is the likely cause and the usage endpoint is
        # worth re-reading now instead of at the next 5-10 minute tick.
        # profile_id -> monotonic time the re-read was asked for; the entry
        # stays after draining so the cap below can see it.
        # Models an api Profile's endpoint answered "not found" for, and the
        # default_model that worked instead. Without this every request to a
        # single-model endpoint (a local model server, a one-deployment
        # gateway) pays the same 404 and retry again — the answer is already
        # known after the first one. profile_id -> set of rejected model names.
        self._models_rejected_by: dict[tuple, set] = {}
        self._usage_recheck_requested: dict[str, float] = {}
        self._usage_recheck_pending: set = set()
        # Set when a re-read should not wait for the next probe tick; the
        # daemon's probe loop waits on it instead of sleeping blind.
        self.usage_recheck_wakeup = threading.Event()
        # Last time (monotonic) each Profile's in-flight request finished.
        # Without this, "Used now" is only ever true for the literal
        # duration of one request/response cycle — for a quick non-streaming
        # call that can be well under the Dashboard's 1s poll interval, so
        # the indicator would flicker on and off between ticks and often
        # never be observed at all. Holding it visible for
        # _USED_NOW_GRACE_SECONDS (a session-length window, not a request-
        # length one — see the class docstring) after the last completion
        # makes it represent "this is the Profile the current session is
        # using" rather than "a request happened to be running a moment
        # ago."
        self._last_active: dict[str, float] = {}
        # Per-Profile throttle for _maybe_check_oauth_credential — maps
        # profile id to the monotonic time before which another refresh
        # attempt must not be made. That method does a real secret_store
        # fetch and, when due, a real network call to Anthropic's token
        # endpoint, so it must not run on every single _sync_snapshot call
        # (every Dashboard poll tick, ~1/s); a 429 response pushes this
        # deadline out much further than a normal attempt does (see
        # _RATE_LIMIT_BACKOFF_SECONDS). See that method's own docstring for
        # what it's actually for.
        self._refresh_check_not_before: dict[str, float] = {}
        self._credential_check_not_before: dict[str, float] = {}
        # Consecutive rate-limited refreshes per Profile, driving the
        # escalating backoff and the give-up threshold above.
        self._refresh_rate_limited_streak: dict[str, int] = {}
        # Consecutive non-429 refresh failures per Profile (a rejected grant,
        # a 5xx, a network error). These escalate too — see refresh_backoff.
        self._refresh_failure_streak: dict[str, int] = {}
        # Guards the check-then-act on the two dicts above, and marks which
        # Profiles have a refresh in flight. Its own lock, not self._lock:
        # _maybe_refresh_credential runs OUTSIDE self._lock (the request path)
        # while _maybe_check_oauth_credential runs inside it (the sync path),
        # so self._lock cannot serialise them — and holding self._lock across
        # a network call would stall every request anyway.
        self._refresh_lock = threading.Lock()
        self._refresh_in_progress: set = set()
        persisted = runtime_state.load()
        self._persisted_profiles: dict = persisted["profiles"]
        self._current_profile_id = persisted["current_profile_id"]

    def _sync_snapshot(self, pool: Pool) -> PoolSnapshot:
        """Folds the persisted Pool (source of truth for config: priority,
        threshold, enabled, automatic) into the live runtime state (source of
        truth for observed state: ELIGIBLE/DRAINING/etc), adding new Profiles
        and dropping deleted ones, never losing observed state for a Profile
        that still exists just because its config changed."""

        live_ids = {p.id for p in pool.profiles}
        self._runtime = {pid: rt for pid, rt in self._runtime.items() if pid in live_ids}

        # An API-kind Profile has no session-% concept the way OAuth's
        # switch_threshold does (there's no Anthropic rate-limit header to
        # read), so token_threshold is its analogue: a hard, absolute
        # lifetime-token-count cap instead of a percentage of a window
        # Anthropic reports. Only computed when at least one Profile
        # actually uses it, and as a SQL aggregate: this runs on every
        # routing decision and on every Dashboard poll, and the version that
        # built an object per stored event made both scale with the size of
        # the user's whole history.
        tokens_by_profile = None
        if any(p.kind == "api" and p.token_threshold for p in pool.profiles):
            tokens_by_profile = usage_history.totals_by_profile()

        def _over_token_budget(p: Profile) -> bool:
            if p.kind != "api" or not p.token_threshold or tokens_by_profile is None:
                return False
            return tokens_by_profile.get(p.id, {}).get("tokens", 0) >= p.token_threshold

        for p in pool.profiles:
            if p.id not in self._runtime:
                state = ProfileState.ELIGIBLE if p.enabled else ProfileState.DISABLED
                if state == ProfileState.ELIGIBLE and _over_token_budget(p):
                    # EXHAUSTED, not DRAINING — DRAINING's status_word
                    # ("near threshold") is right for OAuth's soft,
                    # percentage-based crossing but actively wrong for a
                    # hard, user-set token cap that's already been passed;
                    # EXHAUSTED's own state comment already calls it out as
                    # exactly this: "explicit hard quota".
                    state = ProfileState.EXHAUSTED
                    self._notify_token_budget_exhausted(p, tokens_by_profile, pool)
                persisted = self._persisted_profiles.get(p.id)
                now_utc = datetime.now(timezone.utc)
                # Carry any rate-limit refresh backoff across the restart BEFORE
                # anything below can trigger a refresh (the ELIGIBLE preventive
                # check at the end of this branch, or a later recovery poll for
                # an AUTH_INVALID Profile) — otherwise a rate-limited account
                # re-pokes the token endpoint the instant the daemon comes back.
                self._restore_refresh_backoff(p.id, persisted, now_utc, kind=p.kind)
                restored = {
                    **_restorable_usage_fields(persisted, now=now_utc),
                    **_restorable_state_fields(persisted, now=now_utc),
                }
                # Configuration always wins over a restored state: a Profile
                # disabled while the daemon was down must come back disabled.
                if state == ProfileState.DISABLED:
                    restored.pop("state", None)
                    restored.pop("cooldown_until", None)
                restored_state = restored.pop("state", state)
                self._runtime[p.id] = ProfileRuntime(
                    profile_id=p.id, priority=p.priority, switch_threshold=p.switch_threshold,
                    automatic=p.automatic, kind=p.kind,
                    state=restored_state,
                    credential_seen=p.credential_updated_at,
                    may_spend_credits=_may_spend_credits(p, pool.settings),
                    blocked_models=_blocked_models_for(
                        p, restored.get("model_usage", ()), pool.settings, now_utc),
                    leave_on_fable_limit=_leave_on_fable_limit(p, pool.settings),
                    **restored,
                )
                state = restored_state
                # A Profile this Gateway has just seen for the first time may
                # already be near its real expiry (e.g. right after a restart).
                # The check itself runs in _run_due_credential_checks, OUTSIDE
                # this lock — see that method — so this tick only notes it.

            else:
                rt = self._runtime[p.id]
                new_state = rt.state
                credential_refreshed = (
                    p.credential_updated_at is not None and p.credential_updated_at != rt.credential_seen
                )
                if credential_refreshed:
                    # A replaced credential is a fresh start: drop any
                    # rate-limit backoff and the given-up state, so a
                    # re-authenticated Profile is retried immediately rather
                    # than waiting out a window earned by the old token.
                    self._refresh_rate_limited_streak.pop(p.id, None)
                    self._refresh_failure_streak.pop(p.id, None)
                    self._refresh_check_not_before.pop(p.id, None)
                    self._credential_check_not_before.pop(p.id, None)
                    openai_bridge.forget_refresh_backoff(p.id)
                if not p.enabled:
                    new_state = ProfileState.DISABLED
                elif rt.state == ProfileState.DISABLED and p.enabled:
                    new_state = ProfileState.ELIGIBLE
                elif rt.state == ProfileState.AUTH_INVALID and credential_refreshed:
                    # A stuck AUTH_INVALID Profile is filtered out of choose()'s
                    # candidates and has no time-based recovery (unlike
                    # COOLDOWN/EXHAUSTED) — without this, re-authenticating an
                    # already-registered Profile (CLI `login`, "Import current
                    # login", or re-pasting a token) would never actually clear
                    # the "needs re-auth" status until a manual disable/enable
                    # toggle or a full daemon restart, even though the real
                    # credential behind it is now valid.
                    new_state = ProfileState.ELIGIBLE
                    self._queue_recovered_usage_read(p.id)
                elif (rt.state == ProfileState.DRAINING and p.kind in ("oauth", "codex")
                        and rt.last_usage_percent is not None and rt.last_usage_percent < p.switch_threshold):
                    # Raising switch_threshold can put a DRAINING Profile
                    # back under its own threshold without any new request
                    # ever happening — re-check the LAST OBSERVED number
                    # against the CURRENT (just-edited) threshold right
                    # here, instead of leaving it stuck until the next
                    # real request notices.
                    new_state = ProfileState.ELIGIBLE
                elif (rt.state == ProfileState.EXHAUSTED and p.kind == "api"
                        and p.token_threshold and not _over_token_budget(p)):
                    # Same idea for a token-budget-triggered EXHAUSTED —
                    # raising token_threshold above the current lifetime
                    # usage recovers it immediately.
                    new_state = ProfileState.ELIGIBLE
                # An AUTH_INVALID Profile that self-recovered via its
                # refresh_token is already ELIGIBLE in self._runtime by now:
                # _run_due_credential_checks applied it before this sync, so
                # `rt.state` above carries it. That work used to happen right
                # here, which meant a keychain fork and a token-refresh
                # NETWORK CALL while this lock was held — every Dashboard and
                # widget poll then queued behind it, for 20-45s on a loaded
                # machine, and the widget fell back to its loading state.
                may_spend_credits = _may_spend_credits(p, pool.settings)
                if new_state in (ProfileState.DRAINING, ProfileState.EXHAUSTED) and may_spend_credits and rt.credits_has:
                    # Turning "spend credits" on must take effect now, not at
                    # the next request: an account parked as spent is exactly
                    # the one the user just bought credits for.
                    new_state = ProfileState.ELIGIBLE
                elif (new_state == ProfileState.ELIGIBLE and not may_spend_credits
                        and p.kind == "codex" and rt.last_usage_percent is not None
                        and rt.last_usage_percent >= p.switch_threshold):
                    # And turning it back off must stop the spending now, for
                    # the same reason — a Profile only ELIGIBLE because credits
                    # were allowed has to go back to draining.
                    new_state = ProfileState.DRAINING
                if new_state not in (ProfileState.DISABLED, ProfileState.AUTH_INVALID) and _over_token_budget(p):
                    # No resets_at (there's no time window here) — stays
                    # EXHAUSTED, same as force_active()'s reasoning for
                    # other states, until a real user action clears it:
                    # raising the budget, disabling then re-enabling, or
                    # Take Over. Only notify on the actual crossing, not
                    # every sync while it stays over budget.
                    if new_state != ProfileState.EXHAUSTED:
                        self._notify_token_budget_exhausted(p, tokens_by_profile, pool)
                    new_state = ProfileState.EXHAUSTED
                self._runtime[p.id] = ProfileRuntime(
                    profile_id=p.id, priority=p.priority, switch_threshold=p.switch_threshold,
                    automatic=p.automatic, kind=p.kind, state=new_state,
                    last_usage_percent=rt.last_usage_percent, cooldown_until=rt.cooldown_until,
                    resets_at=rt.resets_at,
                    last_usage_percent_7d=rt.last_usage_percent_7d, resets_at_7d=rt.resets_at_7d,
                    window_label=rt.window_label, window_label_7d=rt.window_label_7d,
                    model_usage=rt.model_usage,   # rebuilt every poll tick; dropping it erased every read
                    credential_seen=p.credential_updated_at,
                    # Must be carried over: this reconstruction runs on every
                    # _sync_snapshot call (roughly every Dashboard poll tick, not
                    # only on a real observation). Rebuilding without it resets
                    # the escalating-backoff streak within about a second of it
                    # being incremented, defeating router.py's no-Retry-After
                    # design (see _cooldown_deadline's own docstring) in
                    # practice any time the Dashboard was open. The exact class
                    # of bug the "Background API retry safety" standing rule
                    # exists to catch, found here by inspection rather than by
                    # a second live incident.
                    consecutive_unretryable_failures=rt.consecutive_unretryable_failures,
                    budget_unavailable=rt.budget_unavailable,
                    # Same rebuild trap as model_usage above: credits are
                    # observed, not configured, so leaving them out would
                    # blank the balance on the next Dashboard poll.
                    credits_has=rt.credits_has, credits_balance=rt.credits_balance,
                    may_spend_credits=may_spend_credits,
                    # Recomputed rather than carried: it depends on the parity
                    # list and on the clock (a bucket expires), both of which
                    # can change between ticks. Leaving it out of THIS
                    # constructor is the trap that has already dropped
                    # model_usage and the credit balance.
                    blocked_models=_blocked_models_for(
                        p, rt.model_usage, pool.settings, datetime.now(timezone.utc)),
                    # Configuration, re-read every tick like priority and
                    # switch_threshold: flipping the Profile's switch or the
                    # global override must apply to the next request. Same
                    # rebuild trap as everything above.
                    leave_on_fable_limit=_leave_on_fable_limit(p, pool.settings),
                )
        if self._current_profile_id not in live_ids:
            self._current_profile_id = None
        if self._fable_limit_noted:
            # A spent-week note is forgotten the moment the account is no
            # longer spent, so the NEXT spent week gets its own line — and a
            # deleted Profile's note goes with it.
            now_utc = datetime.now(timezone.utc)
            self._fable_limit_noted = {pid for pid in self._fable_limit_noted
                                       if pid in self._runtime and fable_spent(self._runtime[pid], now_utc)}
        # A pin naming a Profile that has been deleted (or turned off) is dead
        # weight that would otherwise be re-checked on every request until its
        # TTL; drop it here, where the persisted Pool is already in hand, so
        # those branches simply get re-assigned on their next request.
        if self._branch_pins:
            usable = {p.id for p in pool.profiles if p.enabled}
            for key in [k for k, pin in self._branch_pins.items() if pin.profile_id not in usable]:
                del self._branch_pins[key]
        return PoolSnapshot(profiles=list(self._runtime.values()), current_profile_id=self._current_profile_id)

    @staticmethod
    def _notify_token_budget_exhausted(p: Profile, tokens_by_profile: Optional[dict], pool: Pool) -> None:
        """Fires exactly once per crossing (caller only calls this the
        moment new_state is about to become EXHAUSTED, not on every sync
        while it stays there) — same "needs_attention" category
        AUTH_INVALID already uses, since both mean "this Profile needs a
        real user action before it'll be picked again"."""
        used = tokens_by_profile.get(p.id, {}).get("tokens", 0) if tokens_by_profile else 0
        activity.record("error", f"{p.name} hit its token budget",
                         meta=f"{used}/{p.token_threshold} tokens — excluded from rotation")
        notifications.notify_if_enabled(
            "needs_attention", "Claude Unlimited",
            f"{p.name} hit its token budget ({used}/{p.token_threshold}) — excluded from rotation.", pool.settings)

    def handle(self, method: str, path: str, headers: dict, body: bytes,
               forced_profile_id: Optional[str] = None,
               distribute: bool = False) -> GatewayResult:
        """forced_profile_id (see session_tokens.py) pins this ONE request
        to exactly that Profile — set by a `claude-unlimited code --profile`
        terminal session, and scoped to it alone: unlike force_active()
        ("Take over", a Dashboard-wide sticky override), this never touches
        self._current_profile_id or fires a "Rotated" notification, since
        other concurrent sessions' own rotation must stay exactly as it
        was. A forced request that can't be served returns a clear error
        instead of silently trying a different Profile — silently
        substituting a different account is exactly what pinning is for
        avoiding."""
        now = datetime.now(timezone.utc)
        attempted: set[str] = set()
        thinking_repair_attempted = False
        previous_profile_id = self._current_profile_id
        is_subagent = project_attribution.is_subagent(headers)
        # Which conversation branch is this? None for anything that isn't
        # identifiable Claude Code traffic, which then routes exactly as before.
        # Identifying it JSON-parses the whole body (a conversation can be
        # megabytes), so it is only done when a per-branch mode can apply at
        # all. Checked against a fresh read outside the lock; a setting toggled
        # between here and the decision simply applies from the next request.
        app_pinned = self._app_pinned(headers)
        pool_now = load_pool()
        branch_modes = app_pinned or self._branch_modes_apply(pool_now, distribute, is_subagent)
        # ONE parse of the body per request, and only for branch
        # identification: routing no longer looks at the requested model (a
        # spent Fable week moves the whole session, whatever the model), so a
        # pool with no per-branch mode parses nothing.
        parsed_request = _parsed_request(body) if branch_modes else None
        branch = project_attribution.branch_key(headers, body, parsed_request) if branch_modes else None
        # The capacity guard (docs/adr/0009), once per request and only for a
        # real turn: the same bytes go out on every rotation attempt, and the
        # estimate is computed on the pre-ECO body, which is the larger one
        # (conservative). Almost always None — see _request_guard.
        is_turn = method == "POST" and path.rstrip("/").endswith("/v1/messages")
        guard = _request_guard(body, parsed_request, pool_now) if is_turn else None
        fit = guard.fit if guard is not None else None
        if guard is not None:
            self._note_assumed_windows(pool_now, guard)
        branch_moves: list[tuple[str, str, str]] = []
        parent_agent_id = project_attribution.parent_agent_id_from_headers(headers)
        # Pins are only CREATED for real message traffic — token counting and
        # other ancillary calls never populate the prompt cache, so pinning on
        # them would just burn map slots. Lookups still apply to every path so
        # a branch's side calls ride its existing pin.
        may_create_pin = method == "POST" and path.rstrip("/").endswith("/v1/messages")

        # ECO compacts the body ONCE for this request; every rotation attempt
        # then sends the same compacted bytes. Default tier is "off", in which
        # case this is a no-op returning the original object.
        eco_body: Optional[bytes] = None
        eco_stats = eco.CompactionStats()

        for _ in range(max(MAX_ROTATION_ATTEMPTS, len(pool_now.profiles))):
            # The Profile a pinned request is held to: the pin itself, or —
            # for a subagent — the "Forced in subagents" Profile.
            held_to = forced_profile_id
            with self._lock:
                pool = load_pool()
                snapshot = self._sync_snapshot(pool)
                pre_recovery_states = {rt.profile_id: rt.state for rt in snapshot.profiles}
                snapshot = recover_expired_cooldowns(snapshot, now)
                self._runtime = {rt.profile_id: rt for rt in snapshot.profiles}
                if forced_profile_id is None:
                    snapshot = self._maybe_return_to_preferred(pool, snapshot, now, fit)
                if forced_profile_id is not None:
                    # An explicit --profile pin outranks everything: it must
                    # never be silently substituted, not even by a branch pin.
                    # One deliberate exception: a subagent goes to the Profile
                    # marked "Forced in subagents", when there is one. That flag
                    # is the more specific choice — "orchestrate on this
                    # account, run the workers on that one" — and it is taken
                    # just as strictly as the pin: if that Profile cannot
                    # serve, the subagent fails; it is never rerouted. A
                    # DISABLED holder counts as no holder: subagents then
                    # follow the pin, as they do when nothing is flagged.
                    subagent_target = self._forced_subagent_profile(pool) if is_subagent else None
                    if subagent_target is not None:
                        held_to = subagent_target.id
                    decision = self._forced_decision(pool, held_to, now, fit)
                else:
                    decision = self._branch_decision(
                        pool, snapshot, now, branch, is_subagent, parent_agent_id,
                        attempted, distribute, may_create_pin, moves=branch_moves,
                        app_pinned=app_pinned, fit=fit)
            branch_routed = decision.reason in _BRANCH_ROUTED_REASONS
            for from_id, to_id, why in branch_moves:
                self._record_branch_move(pool, from_id, to_id, why)
            branch_moves.clear()
            if decision.reason == "fable_limit_no_alternative" and decision.profile_id is not None:
                self._note_fable_limit_served_anyway(pool, decision.profile_id, now,
                                                     "no other account can take the session — served anyway")

            for rt in snapshot.profiles:
                if pre_recovery_states.get(rt.profile_id) in _QUOTA_RESET_SOURCE_STATES and rt.state == ProfileState.ELIGIBLE:
                    self._warned_approaching.discard(rt.profile_id)
                    name = self._profile_name(pool, rt.profile_id)
                    activity.record("rotation", f"{name} quota reset — eligible again")
                    notifications.notify_if_enabled("quota_reset", "Claude Unlimited",
                                                      f"{name} is available again.", pool.settings)

            if decision.reason == "no_profile_fits_request" and guard is not None:
                # Capacity exists; no account that may take this request can
                # HOLD it. Not a 503 (Claude Code would hold for ten minutes
                # and retry the same body) but the one error it recovers
                # from: an Anthropic-shaped prompt-too-long, on which it
                # compacts and re-sends — to the same pinned account, or to
                # whichever one the smaller conversation then fits.
                return self._prompt_too_long_result(pool, snapshot, guard, headers, branch,
                                                    held_to)

            if decision.profile_id is None or decision.profile_id in attempted:
                if forced_profile_id is not None:
                    activity.record("error", "Pinned Profile unavailable — request rejected",
                                     meta=f"{held_to}: {decision.reason}, "
                                          f"client={_client_label(headers)}")
                    budget_blocked = self._runtime.get(held_to)
                    if budget_blocked is not None and budget_blocked.budget_unavailable:
                        return GatewayResult(status=402, headers={}, body_chunks=None, profile_id=held_to,
                                             error="provider_budget_unavailable",
                                             error_detail="Pinned provider requires funding (HTTP 402).")
                    return GatewayResult(status=503, headers={}, body_chunks=None, profile_id=None,
                                          error=decision.reason)
                budget_blocked = [rt for rt in snapshot.profiles
                                  if rt.budget_unavailable and rt.state == ProfileState.COOLDOWN
                                  and (rt.automatic or rt.profile_id == snapshot.current_profile_id)
                                  and fits(rt, fit)]
                if budget_blocked:
                    return GatewayResult(status=402, headers={}, body_chunks=None, profile_id=None,
                                         error="provider_budget_unavailable",
                                         error_detail="Configured fallback provider requires funding (HTTP 402); no eligible Profile is available.")
                exhausted, resets_at = _capacity_exhaustion(snapshot, pool)
                # Said ONCE per outage, not once per request: a client that
                # retries in a loop used to write an Activity line and raise a
                # notification every time, burying the one line that mattered.
                if not self._exhaustion_announced:
                    self._exhaustion_announced = True
                    if exhausted:
                        text = "All Profiles are out of capacity — requests rejected"
                        note = _exhaustion_message(resets_at)
                    else:
                        text = "No eligible Profile available — requests rejected"
                        note = "No eligible Profile is available — requests are being rejected."
                    activity.record("error", text,
                                     meta=f"last active was {previous_profile_id}, "
                                          f"client={_client_label(headers)}")
                    notifications.notify_if_enabled("needs_attention", "Claude Unlimited", note,
                                                      pool.settings)
                error_headers = {}
                if exhausted and resets_at is not None:
                    # Seconds until the earliest window reopens, so a client
                    # that honours Retry-After waits for real capacity instead
                    # of hammering a daemon that has none.
                    wait = int((resets_at - datetime.now(timezone.utc)).total_seconds())
                    if wait > 0:
                        error_headers["retry-after"] = str(wait)
                return GatewayResult(status=503, headers=error_headers, body_chunks=None, profile_id=None,
                                      error=("all_profiles_exhausted" if exhausted else "no_eligible_profile"),
                                      error_detail=_exhaustion_message(resets_at) if exhausted else None)

            profile = pool.get(decision.profile_id)
            attempted.add(profile.id)
            if self._exhaustion_announced:
                # Capacity is back. Said once, and it re-arms the outage
                # announcement for next time.
                self._exhaustion_announced = False
                activity.record("rotation", f"Capacity is back — {profile.name} is serving again")

            # GET /v1/models is what Claude Code builds its `/model` picker
            # from. A connector whose real backend isn't Anthropic-shaped
            # answers it locally (see connectors.models_listing); everything
            # else falls through and relays upstream exactly as before, so
            # a Claude Profile keeps serving Anthropic's own live list.
            if method == "GET" and path.startswith("/v1/models"):
                listing = connectors.models_listing(profile.kind, pool.settings.model_parity)
                if listing is not None:
                    return self._models_listing_response(profile, path, listing)

            try:
                credential = secret_store.get_token(profile.id)
            except Exception:
                # NOT QuotaExhausted, which this used to report. A credential
                # store that will not answer is transient — a locked Keychain,
                # a daemon started before first unlock — and says nothing about
                # this account's quota. QuotaExhausted(resets_at=None) has no
                # deadline, and recover_expired_cooldowns() only recovers an
                # EXHAUSTED Profile that HAS one, so a Keychain locked for ten
                # seconds took a perfectly healthy account out of rotation
                # until the next daemon restart, showing "exhausted" as the
                # reason. ProviderUnavailable cools it down for a bounded
                # time and lets it come back on its own.
                with self._lock:
                    self._observe(profile.id, ProviderUnavailable(retry_after_seconds=None), now)
                continue

            # Compact before the kind branch: oauth, api and codex all send the
            # same tool output, so a setting that only reached two of the three
            # would report savings that depend on which account happened to
            # serve you.
            if eco_body is None:
                eco_body, eco_stats = _eco_compact(body, getattr(pool.settings, "eco_tier", "off"))
                # Same place and same reason: every account kind gets it.
                if path.rstrip("/").endswith("/v1/messages"):
                    eco_body, eco_stats = _speech_apply(eco_body, eco_stats,
                                                        getattr(pool.settings, "speech_level", "off"))
                    # Last, so nothing above can reintroduce one.
                    eco_body = _drop_empty_text_blocks(eco_body)

            # Over the limit, first trim the oldest images/documents from the
            # history (media_budget): the session keeps its recent screenshots
            # instead of Claude Code's 413 recovery stripping all of them.
            if path.rstrip("/").endswith("/v1/messages"):
                eco_body = media_budget.fit_body(eco_body, max_request_bytes(profile))

            # The body that would actually be sent (after ECO), against what
            # this Profile's upstream accepts. Answered with the status and
            # shape the provider itself uses for an oversized request, which
            # Claude Code recovers from (it drops the images and compacts)
            # rather than ending the session. It says nothing about the
            # Profile, so: no observation, no cooldown, and no rotation (the
            # next account has the same limit or a lower one).
            try:
                check_request_size(profile, eco_body)
            except RequestTooLarge:
                activity.record("error", "Request too large — rejected",
                                 meta=f"{len(eco_body):,} bytes for {profile.name}, "
                                      f"client={_client_label(headers)}")
                return GatewayResult(status=REQUEST_TOO_LARGE_STATUS, headers={}, body_chunks=None,
                                      profile_id=None, error="request_too_large")

            if profile.kind == "codex":
                result = self._handle_codex(profile, credential, method, path, headers, eco_body, now,
                                             forced_profile_id, previous_profile_id, pool,
                                             branch_routed=branch_routed, eco_stats=eco_stats,
                                             reason=decision.reason)
                if result is not None:
                    return result
                continue  # this attempt failed in a rotate-away way — try the next eligible Profile

            if profile.kind == "oauth":
                credential = self._maybe_refresh_credential(profile, credential)

            # The Claude side of a parity row's reasoning effort: gated to what
            # the requested model actually accepts (None otherwise), so a bad
            # row can never 400 a real request. Only oauth/api /v1/messages
            # bodies are touched, inside build_upstream_request.
            # This endpoint already refused the requested model once: send the
            # Profile's default straight away rather than paying the same 404
            # and retry on every request.
            forced = _force_model_body(profile, eco_body)
            if forced is not None:
                eco_body = forced
            stripped = _strip_billing_header_body(profile, eco_body)
            if stripped is not None:
                eco_body = stripped
            known_bad = self._default_model_body(profile, eco_body)
            if known_bad is not None:
                eco_body = known_bad
            claude_effort = openai_models.claude_effort_for(request_model(eco_body), pool.settings.model_parity)
            try:
                upstream_req = build_upstream_request(profile, credential, method, path, headers, eco_body,
                                                      claude_effort=claude_effort)
            except ValueError:
                # A structurally invalid inbound request (e.g. over the body
                # size cap) — no Profile can serve this; retrying the next
                # one would just repeat the same ValueError until the loop
                # gives up with a misleading "no eligible profile" error.
                # Fail the request itself, immediately.
                return GatewayResult(status=400, headers={}, body_chunks=None, profile_id=None,
                                      error="bad_request")

            # "in flight" from here until either this attempt is abandoned
            # (cleared explicitly below, at every exit that doesn't hand a
            # body back to the caller) or the response body this Profile
            # served is fully drained/closed (cleared by the generator
            # wrapper further down) — backs the Dashboard's "Used now"
            # indicator, which can legitimately be true for MORE than one
            # Profile at once (concurrent `claude-unlimited code --profile`
            # sessions each pinned to a different one).
            with self._lock:
                self._in_flight.add(profile.id)
                self._in_flight_since.setdefault(profile.id, time.monotonic())

            try:
                resp: UpstreamResponse = self._transport(upstream_req)
            except (OSError, http.client.HTTPException):
                # http.client.HTTPException is NOT an OSError, so catching
                # only OSError missed a whole real class of transport failure:
                # BadStatusLine and IncompleteRead from a proxy or middlebox
                # returning a malformed response. Those escaped handle()
                # entirely — the client got a dropped connection with no HTTP
                # status, and the Profile's in-flight slot leaked, which pins
                # "Used now" on forever and wedges the idle check the updater
                # waits for.
                #
                # Real network failure reaching this Profile's upstream
                # (timeout, DNS, connection refused, TLS) — not a quota
                # problem. Same handling as a 503/529 ProviderUnavailable
                # response: brief cooldown, try the next eligible Profile.
                # Previously unhandled here, this could crash the request
                # thread with no HTTP response at all (daemon.py's proxy
                # handler has no guard around Gateway.handle() either).
                # One lock for both: _observe read-modify-writes self._runtime,
                # so doing it unlocked let a concurrent request's completed
                # observation be overwritten by this thread's stale snapshot —
                # silently reviving a Profile another thread had just learned
                # was out of quota.
                with self._lock:
                    self._mark_profile_idle(profile.id)
                    self._observe(profile.id, ProviderUnavailable(retry_after_seconds=None), now)
                if forced_profile_id is not None:
                    # No other Profile to fall back to when pinned — fail
                    # the request clearly instead of a pointless immediate
                    # retry of the same unreachable upstream.
                    activity.record("error", f"{profile.name} — could not reach upstream",
                                     meta="pinned profile, not rotating")
                    return GatewayResult(status=503, headers={}, body_chunks=None, profile_id=None,
                                          error="upstream_unreachable")
                activity.record("error", f"{profile.name} — could not reach upstream",
                                 meta="network error, rotating to next eligible profile")
                continue
            except BaseException:
                # Anything else is a bug, and should surface as one — but not
                # while silently leaking this Profile's in-flight slot, which
                # nothing else would ever clear.
                with self._lock:
                    self._mark_profile_idle(profile.id)
                raise

            observation = classify(resp.status, filter_response_headers(resp.headers), now)

            signature_target = urlparse(upstream_req.url) if resp.status == 400 else None
            if (resp.status == 400 and not thinking_repair_attempted
                    and upstream_req.method == "POST" and signature_target.scheme == "https"
                    and signature_target.hostname == "api.anthropic.com"
                    and signature_target.path.rstrip("/") == "/v1/messages"):
                # Only a provider-confirmed historical signature rejection can
                # rewrite signed history. Success streams remain untouched and
                # a repair never mutates the caller's stored conversation.
                try:
                    signature_error, resp = _peek_error_body(resp)
                except (OSError, http.client.HTTPException):
                    # A partial error body cannot be relayed as a complete400.
                    # Release the slot and use the existing upstream-failure
                    # policy before any response bytes reach the caller.
                    resp.connection.close()
                    with self._lock:
                        self._mark_profile_idle(profile.id)
                        self._observe(profile.id, ProviderUnavailable(retry_after_seconds=None), now)
                    if forced_profile_id is not None:
                        activity.record("error", f"{profile.name} — could not reach upstream",
                                        meta="pinned profile, error body disconnected")
                        return GatewayResult(status=503, headers={}, body_chunks=None, profile_id=None,
                                             error="upstream_unreachable")
                    activity.record("error", f"{profile.name} — could not reach upstream",
                                    meta="error body disconnected, rotating to next eligible profile")
                    continue
                repaired_req = retry_without_rejected_thinking(upstream_req, resp.status, signature_error)
                if repaired_req is not None:
                    thinking_repair_attempted = True
                    try:
                        repaired_resp = self._transport(repaired_req)
                    except (OSError, http.client.HTTPException):
                        # The peek completed and restored the original body.
                        # Preserve that actual400 if the one repair send fails.
                        pass
                    else:
                        resp.connection.close()
                        resp = repaired_resp
                        # Carry only repaired history, not the first profile's
                        # injected account UUID/effort. Subsequent profiles
                        # rebuild their own request metadata and auth headers.
                        repaired_history = json.loads(repaired_req.body)["messages"]
                        canonical_body = json.loads(eco_body)
                        canonical_body["messages"] = repaired_history
                        eco_body = json.dumps(canonical_body).encode("utf-8")
                        observation = classify(resp.status, filter_response_headers(resp.headers), now)
                        activity.record("session", "Retried rejected historical thinking signature",
                                        meta="one request-only repair; active tool turn preserved")

            if (profile.kind == "api" and profile.default_model
                    and isinstance(observation, Unknown) and observation.status_code in _MODEL_FALLBACK_STATUS_CODES):
                # Read the (small) error body to tell "model not found" from
                # everything else a 400 can mean. A "prompt is too long" 400
                # used to be taken for a model refusal: it retried with the
                # default model, logged "<model> unavailable", and remembered
                # the model as refused — which, with a forced model, would move
                # every later request off it for good after one large prompt.
                try:
                    error_body, resp = _peek_error_body(resp)
                except (OSError, http.client.HTTPException):
                    # The connection dropped while the error body was read —
                    # the same failure as one before the headers: release
                    # the slot, cool the Profile down, rotate (or fail, when
                    # pinned) exactly as the network-error branch above does.
                    resp.connection.close()
                    with self._lock:
                        self._mark_profile_idle(profile.id)
                        self._observe(profile.id, ProviderUnavailable(retry_after_seconds=None), now)
                    if forced_profile_id is not None:
                        activity.record("error", f"{profile.name} — could not reach upstream",
                                         meta="pinned profile, not rotating")
                        return GatewayResult(status=503, headers={}, body_chunks=None, profile_id=None,
                                              error="upstream_unreachable")
                    activity.record("error", f"{profile.name} — could not reach upstream",
                                     meta="network error, rotating to next eligible profile")
                    continue
                if _is_model_refusal(observation.status_code, error_body):
                    self._remember_rejected_model(profile, request_model(eco_body))
                    retried = self._maybe_retry_with_default_model(
                        profile, credential, method, path, headers, eco_body, now,
                        parity=pool.settings.model_parity)
                    if retried is not None:
                        resp.connection.close()  # the first attempt's response is being discarded
                        resp, observation = retried

            old_rt = self._runtime.get(profile.id)
            old_state = old_rt.state if old_rt is not None else None
            with self._lock:
                self._observe(profile.id, observation, now)
            self._maybe_request_usage_recheck(profile.id, observation)
            new_rt = self._runtime.get(profile.id)
            self._persist()

            if isinstance(observation, AuthInvalid) and old_state != ProfileState.AUTH_INVALID:
                activity.record("error", f"{profile.name} needs re-authentication", meta="credential rejected")
                notifications.notify_if_enabled("needs_attention", "Claude Unlimited",
                                                  f"{profile.name} needs re-authentication.", pool.settings)

            if isinstance(observation, UsageSnapshot) and new_rt is not None and new_rt.state == ProfileState.ELIGIBLE:
                near_threshold = observation.percent >= new_rt.switch_threshold - APPROACHING_THRESHOLD_BAND
                if near_threshold and profile.id not in self._warned_approaching:
                    self._warned_approaching.add(profile.id)
                    notifications.notify_if_enabled(
                        "approaching_threshold", "Claude Unlimited",
                        f"{profile.name} is approaching its switch threshold "
                        f"({observation.percent:.0f}% / {new_rt.switch_threshold:.0f}%).", pool.settings)
                elif not near_threshold:
                    self._warned_approaching.discard(profile.id)

            if isinstance(observation, BudgetUnavailable):
                activity.record("error", f"{profile.name} — provider requires funding (HTTP 402)",
                                meta="billing cooldown for one hour")
                if forced_profile_id is None:
                    with self._lock:
                        self._mark_profile_idle(profile.id)
                    resp.connection.close()
                    continue

            if isinstance(observation, QuotaExhausted):
                if forced_profile_id is not None:
                    # No other Profile to fall back to when pinned — relay
                    # Anthropic's real quota-exhausted response as-is
                    # instead of rotating away from the one Profile the
                    # user explicitly chose for this terminal.
                    activity.record("rotation", f"{profile.name} hit its quota",
                                     meta="pinned profile — returning the real response, not rotating")
                else:
                    # Headers/status only have arrived so far — no body
                    # byte has reached the caller yet. Safe to retry on the
                    # next profile.
                    with self._lock:
                        self._mark_profile_idle(profile.id)
                    resp.connection.close()
                    activity.record("rotation", f"{profile.name} hit its quota", meta="rotating to next eligible profile")
                    continue

            if forced_profile_id is None and not branch_routed:
                # A pinned session's requests must never move the shared
                # rotation pointer or fire a "Rotated" notification — other
                # concurrent terminals may be relying on normal rotation at
                # the exact same time (see handle()'s docstring). The same
                # holds for a branch-routed request (a subagent on its own
                # account): it speaks for ONE branch, not for the pool.
                with self._lock:
                    self._current_profile_id = profile.id
                self._persist()
                if previous_profile_id is not None and previous_profile_id != profile.id:
                    self._announce_rotation(pool, previous_profile_id, profile, decision.reason)
                    # A real rotation switch clears the PREVIOUS Profile's
                    # "Used now" immediately rather than leaving it to
                    # linger for the rest of _USED_NOW_GRACE_SECONDS — the
                    # whole point of that grace window is to survive short
                    # gaps BETWEEN requests on the same still-in-use
                    # Profile, not to keep showing a Profile as active
                    # after rotation has genuinely moved on from it. Safe
                    # even if some other pinned session is concurrently
                    # using previous_profile_id too: that session's own
                    # in-flight marking (self._in_flight, not
                    # self._last_active) is untouched by this, so
                    # in_flight_ids() still reports it correctly.
                    with self._lock:
                        self._last_active.pop(previous_profile_id, None)

            project_id = None
            try:
                session_id = project_attribution.session_id_from_headers(headers)
                if session_id:
                    project_id = project_attribution.resolve_project(session_id)
                    if project_id:
                        project_usage.record_request(project_id)
            except Exception:
                project_id = None  # best-effort attribution — must never affect a real request

            body_chunks = self._wrap_with_usage_capture(resp.body_chunks, resp.headers, profile.id, project_id,
                                                         eco_stats=eco_stats,
                                                         sent_bytes=len(eco_body or body))
            body_chunks = self._wrap_with_in_flight_clear(body_chunks, profile.id)
            return GatewayResult(status=resp.status, headers=resp.headers, body_chunks=body_chunks,
                                  profile_id=profile.id)

        with self._lock:
            budget_blocked = any(
                rt.budget_unavailable and rt.state == ProfileState.COOLDOWN
                and (rt.automatic or rt.profile_id == self._current_profile_id)
                and fits(rt, fit)
                for rt in self._runtime.values()
                if pool.get(rt.profile_id) is not None and pool.get(rt.profile_id).enabled
            )
        if budget_blocked:
            return GatewayResult(status=402, headers={}, body_chunks=None, profile_id=None,
                                 error="provider_budget_unavailable",
                                 error_detail="Configured fallback provider requires funding (HTTP 402); no eligible Profile is available.")
        activity.record("error", "Rotation attempts exhausted without a usable Profile")
        notifications.notify_if_enabled("needs_attention", "Claude Unlimited",
                                          "Rotation attempts exhausted — no usable Profile was found.", pool.settings)
        return GatewayResult(status=503, headers={}, body_chunks=None, profile_id=None,
                              error="rotation_attempts_exhausted")

    def _maybe_check_oauth_credential(self, p: Profile, rt: ProfileRuntime) -> Optional[ProfileState]:
        """Runs at most once every _REFRESH_CHECK_COOLDOWN_SECONDS per
        Profile, called from every _sync_snapshot — i.e. every Dashboard
        poll tick AND the daemon's own periodic background thread (see
        daemon.py), NOT just when a live proxy request happens to route
        to this exact Profile.

        Without this, _maybe_refresh_credential's proactive refresh only
        ever fires from inside handle(), which only runs for a Profile
        choose() actually selected — a Profile that's ELIGIBLE but simply
        idle (not picked this rotation, or nobody sent any request at all
        for a while) can sail past its access token's real expiry with
        zero refresh attempts, then get a genuine 401 the next time it
        IS picked... and a Profile that's already AUTH_INVALID is by
        definition never selected by choose() again, so it could never
        even reach that per-request refresh path to begin with — a stuck
        Profile had no way back except a full manual re-auth, even when
        its refresh_token alone would have worked fine. Sitting on the
        non-current side of rotation for longer than the access token's TTL
        is enough to strand a Profile this way.

        Returns ProfileState.ELIGIBLE if this call just recovered an
        AUTH_INVALID Profile (caller should transition it). Returns None
        for every other outcome — not oauth, not due for a check yet,
        healthy and nowhere near expiry, or a refresh that was attempted
        but failed (a genuinely dead/revoked refresh_token correctly
        stays AUTH_INVALID; this never fakes a recovery)."""
        if p.kind != "oauth" or rt.state == ProfileState.DISABLED:
            return None
        if not self._refresh_attempt_due(p.id):
            # Checked BEFORE the secret_store read, not after. The read forks
            # the `security` CLI on macOS, and this method runs for every
            # oauth Profile on every _sync_snapshot — i.e. every ~1s Dashboard
            # poll — while the gateway lock every request also needs is held.
            # The throttle used to live only inside _try_refresh, so it gated
            # the network call but not the subprocess, which is exactly what
            # this field's own docstring says must not happen.
            return None
        if rt.state != ProfileState.AUTH_INVALID:
            # A rejected Profile is already paced by _refresh_attempt_due above
            # (and its own re-auth recovery cooldown); it must be free to
            # notice a repaired credential. Everything else — healthy,
            # no refresh token, unreadable — is throttled here, claimed
            # before reading so a failed read counts too, without consuming
            # the refresh slot.
            with self._refresh_lock:
                check_now = time.monotonic()
                if check_now < self._credential_check_not_before.get(p.id, 0):
                    return None
                self._credential_check_not_before[p.id] = check_now + self._REFRESH_CHECK_COOLDOWN_SECONDS
        try:
            stored = secret_store.get_token(p.id)
        except Exception:
            return None
        cred = oauth_credential.decode(stored)
        if not cred.refresh_token:
            return None
        was_auth_invalid = rt.state == ProfileState.AUTH_INVALID
        if not was_auth_invalid and not oauth_credential.is_expiring_soon(cred):
            return None  # healthy and not close to expiry — nothing to do yet
        # An AUTH_INVALID Profile's access token already proved itself dead
        # via a real 401 — worth trying the refresh_token unconditionally,
        # regardless of what its stored expires_at claims (that's exactly
        # is_expiring_soon's gate, which only makes sense for the
        # preventive/not-yet-broken case). _try_refresh still owns the
        # shared throttle either way — see its own docstring for why that
        # must never be bypassed.
        try:
            refreshed = self._try_refresh(
                p.id, cred.refresh_token,
                cooldown=self._REAUTH_RECOVERY_COOLDOWN_SECONDS if was_auth_invalid else None,
                profile_name=p.name,
                # Already announced as needing re-auth when its 401 landed.
                notify_on_rejection=not was_auth_invalid)
        except oauth_login.OAuthLoginError as exc:
            # _try_refresh has logged it and set the backoff. A refused grant
            # on an access token that has ALREADY expired cannot serve again:
            # say so now rather than on the next request's 401. One that still
            # has time left keeps serving until it actually fails.
            if (not was_auth_invalid and refresh_backoff.is_rejection(exc.status_code)
                    and cred.expires_at is not None and time.time() * 1000 >= cred.expires_at):
                return ProfileState.AUTH_INVALID
            return None
        if refreshed is None:
            return None  # still within the shared backoff window — not due yet
        try:
            profile_repo.update_credential(
                p.id, refreshed.access_token,
                refresh_token=refreshed.refresh_token or cred.refresh_token,
                expires_at=refreshed.expires_at,
            )
        except Exception:
            return None
        if was_auth_invalid:
            activity.record("rotation", f"{p.name} — token refreshed automatically, back online")
            return ProfileState.ELIGIBLE
        return None

    def _maybe_check_codex_credential(self, p: Profile, rt: ProfileRuntime) -> Optional[ProfileState]:
        """The codex-kind counterpart of _maybe_check_oauth_credential.

        It exists because the oauth version starts `if p.kind != "oauth"`, so
        for a while a codex Profile had NO route out of AUTH_INVALID at all:
        choose() never picks an AUTH_INVALID Profile, the per-request refresh
        in openai_bridge only ever runs for a Profile that WAS picked, and
        AUTH_INVALID is one of the few states restored across a daemon
        restart. One transient 401 stranded an account holding a perfectly
        good refresh_token until someone re-authenticated it by hand — while
        the identical situation on an oauth Profile healed itself. The rule
        this broke is that a behaviour verified on one Profile kind is
        verified on none.

        Deliberately delegates to openai_bridge.refresh_now() rather than
        calling openai_login itself, so this path and the per-request path
        share one backoff clock — see that function's docstring."""
        if p.kind != "codex" or rt.state == ProfileState.DISABLED:
            return None
        if p.auth_mode != "chatgpt_subscription":
            return None  # a raw OpenAI API key has no refresh token to try
        if not openai_bridge.refresh_attempt_due(p.id):
            return None  # before the keychain read, same reasoning as above
        try:
            cred = openai_credential.decode(secret_store.get_token(p.id))
        except Exception:
            return None
        if not cred.refresh_token:
            return None
        was_auth_invalid = rt.state == ProfileState.AUTH_INVALID
        # Same asymmetry as the oauth path: an AUTH_INVALID access token has
        # already proved itself dead via a real 401, so it is worth trying the
        # refresh_token regardless of what its stored expiry claims.
        if not was_auth_invalid and not openai_credential.is_expiring_soon(cred.access_token):
            return None
        try:
            refreshed = openai_bridge.refresh_now(
                p.id, cred, profile_name=p.name,
                cooldown=self._REAUTH_RECOVERY_COOLDOWN_SECONDS if was_auth_invalid else None)
        except Exception:
            refreshed = None
        if refreshed is None:
            # Throttled, or a genuinely dead refresh_token. Either way this
            # never fakes a recovery — a revoked grant correctly stays
            # AUTH_INVALID until the person re-authenticates. A refused grant
            # on an access token already past its expiry is AUTH_INVALID now,
            # exactly as on the oauth path; one with time left keeps serving.
            expires_at = openai_credential.access_token_expires_at(cred.access_token)
            if (not was_auth_invalid and openai_bridge.refresh_was_rejected(p.id)
                    and expires_at is not None and time.time() >= expires_at):
                return ProfileState.AUTH_INVALID
            return None
        if was_auth_invalid:
            activity.record("rotation", f"{p.name} — token refreshed automatically, back online")
            return ProfileState.ELIGIBLE
        return None

    def _handle_codex(self, profile: Profile, credential: str, method: str, path: str, headers: dict,
                       body: bytes, now: datetime, forced_profile_id: Optional[str],
                       previous_profile_id: Optional[str], pool: Pool,
                       branch_routed: bool = False,
                       eco_stats: Optional["eco.CompactionStats"] = None,
                       reason: str = "") -> Optional["GatewayResult"]:
        """The codex-kind analogue of handle()'s main oauth/api body — kept
        as a separate method rather than inlined in the same branch,
        because openai_bridge.run() owns its own HTTP call and response
        translation entirely (it is not a thin build-request/send pair the
        rest of handle()'s shared plumbing can operate on unmodified the
        way an UpstreamResponse can). Mirrors the surrounding loop's own
        contract: returns a GatewayResult to end the request (success or a
        pinned-Profile failure), or None to mean "this attempt failed in a
        way that should rotate to the next eligible Profile" — the caller
        does the actual `continue`.

        Only /v1/messages is bridged for real; every other path a real
        Claude Code session hits (count_tokens, models list, ...) has no
        faithful OpenAI equivalent to translate to, so those get a
        lightweight local answer instead of being mistranslated."""
        if path != "/v1/messages":
            return self._codex_non_messages_response(profile, path, body)

        with self._lock:
            self._in_flight.add(profile.id)
            self._in_flight_since.setdefault(profile.id, time.monotonic())

        try:
            branch = project_attribution.branch_key(headers, body)
            result = openai_bridge.run(profile, credential, body,
                                        parity=pool.settings.model_parity,
                                        context=openai_bridge.ConversationContext(
                                            claude_session_id=branch[0] if branch else None,
                                            agent_id=(branch[1] if branch and branch[1] != project_attribution.MAIN_BRANCH
                                                      else None),
                                            parent_agent_id=project_attribution.parent_agent_id_from_headers(headers)))
        except openai_bridge.OpenAIBridgeError as exc:
            with self._lock:  # same atomicity reasoning as the Anthropic path
                self._mark_profile_idle(profile.id)
                self._observe(profile.id, ProviderUnavailable(retry_after_seconds=None), now)
            if forced_profile_id is not None:
                activity.record("error", f"{profile.name} — could not reach OpenAI",
                                 meta=f"pinned profile, not rotating ({exc})")
                return GatewayResult(status=503, headers={}, body_chunks=None, profile_id=None,
                                      error="upstream_unreachable")
            activity.record("error", f"{profile.name} — could not reach OpenAI",
                             meta=f"network error, rotating to next eligible profile ({exc})")
            return None
        except BaseException:
            # Same reasoning as the Anthropic path: an unexpected failure must
            # still surface, but not while leaking this Profile's in-flight
            # slot, which nothing else clears.
            with self._lock:
                self._mark_profile_idle(profile.id)
            raise

        codex_headers = _filter_openai_headers(result.headers)
        observation = openai_observation.classify(result.status, codex_headers, now)
        # Credits ride along on both 200s and 429s and never decide a state on
        # their own, so they are recorded before the observation is folded in:
        # the QuotaExhausted branch in router._apply reads credits_has to
        # decide whether this account can still serve (issue #6).
        credits = openai_observation.parse_credits(codex_headers)
        if credits is not None:
            with self._lock:
                self._record_credits(profile.id, credits)

        old_rt = self._runtime.get(profile.id)
        old_state = old_rt.state if old_rt is not None else None
        with self._lock:
            self._observe(profile.id, observation, now)
        self._maybe_request_usage_recheck(profile.id, observation)
        new_rt = self._runtime.get(profile.id)
        self._persist()

        if isinstance(observation, AuthInvalid) and old_state != ProfileState.AUTH_INVALID:
            activity.record("error", f"{profile.name} needs re-authentication", meta="credential rejected")
            notifications.notify_if_enabled("needs_attention", "Claude Unlimited",
                                              f"{profile.name} needs re-authentication.", pool.settings)

        if isinstance(observation, UsageSnapshot) and new_rt is not None and new_rt.state == ProfileState.ELIGIBLE:
            near_threshold = observation.percent >= new_rt.switch_threshold - APPROACHING_THRESHOLD_BAND
            if near_threshold and profile.id not in self._warned_approaching:
                self._warned_approaching.add(profile.id)
                notifications.notify_if_enabled(
                    "approaching_threshold", "Claude Unlimited",
                    f"{profile.name} is approaching its switch threshold "
                    f"({observation.percent:.0f}% / {new_rt.switch_threshold:.0f}%).", pool.settings)
            elif not near_threshold:
                self._warned_approaching.discard(profile.id)

        if isinstance(observation, BudgetUnavailable):
            # Same as the Anthropic path: one-hour billing cooldown, and an
            # unpinned request moves to the next account.
            activity.record("error", f"{profile.name} — provider requires funding (HTTP 402)",
                            meta="billing cooldown for one hour")
            if forced_profile_id is None:
                with self._lock:
                    self._mark_profile_idle(profile.id)
                return None

        if isinstance(observation, QuotaExhausted):
            if forced_profile_id is not None:
                activity.record("rotation", f"{profile.name} hit its quota",
                                 meta="pinned profile — returning the real response, not rotating")
            else:
                with self._lock:
                    self._mark_profile_idle(profile.id)
                activity.record("rotation", f"{profile.name} hit its quota", meta="rotating to next eligible profile")
                return None

        # Same rule as the oauth/api path: a pinned OR branch-routed request
        # speaks for one terminal/branch, never for the shared pointer.
        if forced_profile_id is None and not branch_routed:
            with self._lock:
                self._current_profile_id = profile.id
            self._persist()
            if previous_profile_id is not None and previous_profile_id != profile.id:
                self._announce_rotation(pool, previous_profile_id, profile, reason)
                with self._lock:
                    self._last_active.pop(previous_profile_id, None)

        project_id = None
        try:
            session_id = project_attribution.session_id_from_headers(headers)
            if session_id:
                project_id = project_attribution.resolve_project(session_id)
                if project_id:
                    project_usage.record_request(project_id)
        except Exception:
            project_id = None

        # Deliberately NOT result.headers here — those are OpenAI's own raw
        # response headers (Cloudflare ray/cookies, x-codex-* quota
        # telemetry, etc.), already consumed above for rotation/observation
        # purposes but never meant to reach the client: Claude Code expects
        # an Anthropic-shaped response, and leaking a different provider's
        # infrastructure headers through would be a real, visible tell,
        # not just noise. Every codex-kind response is translated SSE
        # (openai_translate.ResponseTranslator's whole job), so this is
        # always the same clean content-type — nothing upstream-specific
        # to preserve.
        # A non-2xx result carries a single plain-JSON error object
        # (openai_bridge.run()'s _error_chunks()), never SSE — only a real
        # 200 is actually the translated event stream.
        content_type = "text/event-stream; charset=utf-8" if result.status < 300 else "application/json"
        client_headers = {"content-type": content_type}
        # One parse of the inbound body, shared by both readers below: what the
        # client asked for (recorded beside the OpenAI model that actually ran)
        # and whether it wants SSE back.
        parsed_body = _parsed_request(body)
        body_chunks = self._wrap_with_usage_capture(result.body_chunks, client_headers, profile.id, project_id,
                                                     requested_model=_requested_model(parsed_body),
                                                     eco_stats=eco_stats, sent_bytes=len(body),
                                                     quota_5h_percent=_codex_5h_percent(result.headers))
        body_chunks = self._wrap_with_in_flight_clear(body_chunks, profile.id)

        # The upstream Responses call is always streamed, but the client
        # decides how it wants the answer back. A client that asked for
        # stream:false cannot parse an SSE body and reads the whole model as
        # unavailable — which is how Claude Code's auto-mode safety
        # classifier (a non-streaming call) ends up blocking tools that need
        # a safety decision.
        if result.status < 300 and not _client_wants_streaming(parsed_body):
            message = openai_translate.assemble_message_from_sse(body_chunks)
            payload = json.dumps(message).encode("utf-8")
            client_headers = {"content-type": "application/json"}
            # A stream that began 200 and then failed still has to be reported
            # as a failure to a non-streaming client; answering 200 with an
            # empty message is what made a failed turn look like a model that
            # simply said nothing.
            status = 502 if message.get("type") == "error" else result.status
            if status != result.status:
                activity.record("error", f"{profile.name} — upstream response failed",
                                meta=str((message.get("error") or {}).get("message", ""))[:200])
            return GatewayResult(status=status, headers=client_headers,
                                  body_chunks=iter([payload]), profile_id=profile.id)

        return GatewayResult(status=result.status, headers=client_headers, body_chunks=body_chunks,
                              profile_id=profile.id)

    # ---- the `codex` CLI, served from the pool (issue #7) -------------------

    _CODEX_CLI_PIN_CAP = 512

    @staticmethod
    def _codex_cli_result(status: int, payload: bytes, headers: Optional[dict] = None) -> "GatewayResult":
        return GatewayResult(status=status, headers={"content-type": "application/json", **(headers or {})},
                              body_chunks=iter([payload]), profile_id=None)

    @staticmethod
    def _codex_cli_candidate_ids(pool: Pool) -> set:
        """Only ChatGPT-subscription Codex accounts can serve the codex CLI
        without translation: Claude accounts would need the reverse of the
        bridge, and an OpenAI API key talks to a different backend."""
        return {p.id for p in pool.profiles
                if p.enabled and p.kind == "codex" and p.auth_mode == "chatgpt_subscription"}

    def _codex_cli_decision(self, pool: Pool, snapshot: PoolSnapshot, now: datetime, thread: Optional[str],
                            attempted: set, forced_profile_id: Optional[str]) -> RoutingDecision:
        """Caller holds self._lock. A conversation stays on the account it is
        pinned to while that account can serve; otherwise router.choose() over
        the Codex accounts alone, sticky on this path's own pointer."""
        candidates = self._codex_cli_candidate_ids(pool)
        if forced_profile_id is not None:
            if forced_profile_id not in candidates:
                return RoutingDecision(profile_id=None, reason="forced_profile_not_chatgpt")
            return self._forced_decision(pool, forced_profile_id, now)
        runtimes = [rt for rt in snapshot.profiles if rt.profile_id in candidates and rt.profile_id not in attempted]
        pinned = self._codex_cli_pins.get(thread) if thread else None
        start = pinned if pinned in {rt.profile_id for rt in runtimes} else self._codex_cli_current_id
        return choose(PoolSnapshot(profiles=runtimes, current_profile_id=start), now)

    def _codex_cli_unavailable(self, pool: Pool, snapshot: PoolSnapshot, reason: str,
                               forced_profile_id: Optional[str]) -> "GatewayResult":
        """Why nothing can serve, in the shape codex acts on: out of capacity
        is its own usage-limit error (it prints when to try again and does
        not retry); anything the user has to fix is a 400, shown as is."""
        if forced_profile_id is not None:
            name = self._profile_name(pool, forced_profile_id)
            why = {"forced_profile_not_chatgpt": "is not a ChatGPT-subscription account, so it cannot serve codex",
                   "forced_profile_missing": "no longer exists",
                   "forced_profile_disabled": "is disabled",
                   "forced_profile_needs_reauth": "needs re-authentication — run `claude-unlimited add-codex-account`",
                   "forced_profile_credential_unreadable": "has a stored credential that could not be read "
                                                           "(is the OS keystore locked?)",
                   }.get(reason, f"cannot serve right now ({reason})")
            activity.record("error", "codex CLI: pinned profile unavailable — request rejected",
                             meta=f"{name}: {reason}")
            return self._codex_cli_result(400, codex_cli.error_body(f"The pinned profile {name} {why}."))
        candidates = self._codex_cli_candidate_ids(pool)
        if not candidates:
            return self._codex_cli_result(400, codex_cli.error_body(
                "No enabled ChatGPT-subscription account in the pool can serve codex. "
                "Add one with `claude-unlimited add-codex-account`, or enable one in the Dashboard."))
        ours = PoolSnapshot(profiles=[rt for rt in snapshot.profiles if rt.profile_id in candidates],
                            current_profile_id=None)
        exhausted, resets_at = _capacity_exhaustion(ours, pool)
        if exhausted:
            headers = {}
            if resets_at is not None:
                wait = int((resets_at - datetime.now(timezone.utc)).total_seconds())
                if wait > 0:
                    headers["retry-after"] = str(wait)
            activity.record("error", "codex CLI: every ChatGPT account is out of capacity — request rejected")
            return self._codex_cli_result(429, codex_cli.usage_limit_body(
                resets_at, "Every ChatGPT account in the pool has reached its limit."), headers)
        return self._codex_cli_result(400, codex_cli.error_body(
            "No ChatGPT account in the pool can serve right now — check the Dashboard "
            "(an account may need re-authentication: `claude-unlimited add-codex-account`)."))

    def handle_codex_cli(self, headers: dict, body: bytes,
                         forced_profile_id: Optional[str] = None) -> "GatewayResult":
        """One request from the official `codex` CLI (POST /codex/v1/responses),
        relayed to the ChatGPT Codex backend on a pool account — see
        codex_cli.py for the wire rules.

        All failover happens HERE, before the first byte goes back: codex
        never retries a 429 itself, so an account running out has to be
        absorbed by moving the same request to the next account. Once the
        stream has started it is relayed as is; a failure after that is the
        provider's, reported, never retried on another account.

        None of the Claude Code path runs here — no ECO, speech, capacity
        guard, model mapping or parity — the body is codex's own and goes
        out unchanged, except that a conversation moving to a different
        account loses the reasoning ciphertext the previous one minted."""
        now = datetime.now(timezone.utc)
        pool = load_pool()
        if not pool.settings.codex_cli_serving:
            return self._codex_cli_result(400, codex_cli.error_body(
                "Serving the codex CLI is turned off. Turn it on in the Dashboard: "
                "Settings → Routing → Codex CLI."))
        encoding = {k.lower(): v for k, v in headers.items()}.get("content-encoding", "identity")
        if encoding.lower() not in ("", "identity"):
            return self._codex_cli_result(400, codex_cli.error_body(
                f"Compressed request bodies ({encoding}) are not supported — start codex with "
                "`claude-unlimited codex`."))
        try:
            parsed = json.loads(body)
            if not isinstance(parsed, dict):
                raise ValueError
        except ValueError:
            return self._codex_cli_result(400, codex_cli.error_body("The request body is not a JSON object."))

        thread = codex_cli.thread_key(parsed, headers)
        requested_model = parsed.get("model") if isinstance(parsed.get("model"), str) else None
        attempted: set = set()
        for _ in range(MAX_ROTATION_ATTEMPTS):
            with self._lock:
                pool = load_pool()
                snapshot = self._sync_snapshot(pool)
                snapshot = recover_expired_cooldowns(snapshot, now)
                self._runtime = {rt.profile_id: rt for rt in snapshot.profiles}
                decision = self._codex_cli_decision(pool, snapshot, now, thread, attempted, forced_profile_id)
                previous_for_thread = self._codex_cli_pins.get(thread) if thread else None
            if decision.profile_id is None or decision.profile_id in attempted:
                return self._codex_cli_unavailable(pool, snapshot, decision.reason, forced_profile_id)
            profile = pool.get(decision.profile_id)
            attempted.add(profile.id)
            try:
                check_request_size(profile, body)
            except RequestTooLarge as exc:
                # The request's own fault, the same on every account: 413, not
                # a rotation and never a 5xx (codex retries those).
                activity.record("error", "codex CLI: request too large — rejected", meta=str(exc))
                return self._codex_cli_result(REQUEST_TOO_LARGE_STATUS, codex_cli.error_body(
                    f"The request is too large for the Codex backend ({exc}).", error_type="request_too_large"))

            try:
                cred = openai_credential.decode(secret_store.get_token(profile.id))
            except Exception:
                with self._lock:   # a locked keystore is transient, not this account's quota
                    self._observe(profile.id, ProviderUnavailable(retry_after_seconds=None), now)
                if forced_profile_id is not None:
                    return self._codex_cli_unavailable(pool, snapshot, "forced_profile_credential_unreadable",
                                                       forced_profile_id)
                continue
            cred = openai_bridge._refresh_if_needed(profile, cred)

            moved = previous_for_thread is not None and previous_for_thread != profile.id
            payload, dropped = (codex_cli.strip_account_bound(parsed) if moved else (body, 0))
            with self._lock:
                self._in_flight.add(profile.id)
                self._in_flight_since.setdefault(profile.id, time.monotonic())
            conn = None
            raw = b""
            try:
                status, resp_headers, resp, conn = codex_cli.send(
                    cred, payload, codex_cli.outbound_headers(headers, cred, len(payload), keep_turn_state=not moved))
                if (status == 400 and not moved and codex_cli.has_account_bound_items(parsed)):
                    # A conversation this daemon has not seen before (resumed
                    # after a restart, or begun on the user's own login) may
                    # carry another account's ciphertext. Retry once without it.
                    text = resp.read().decode("utf-8", errors="replace")
                    conn.close()
                    if not codex_cli.looks_like_refused_ciphertext(status, text):
                        return self._codex_cli_finish_error(profile, status, resp_headers, text.encode("utf-8"))
                    payload, dropped = codex_cli.strip_account_bound(parsed)
                    moved = True
                    status, resp_headers, resp, conn = codex_cli.send(
                        cred, payload, codex_cli.outbound_headers(headers, cred, len(payload), keep_turn_state=False))
                if status >= 400:
                    raw = resp.read()
                    conn.close()
            except (openai_bridge.OpenAIBridgeError, OSError, http.client.HTTPException) as exc:
                # An error body cut short is as much a failed request as a
                # failed connect: free the account and move on.
                if conn is not None:
                    conn.close()
                with self._lock:
                    self._mark_profile_idle(profile.id)
                    self._observe(profile.id, ProviderUnavailable(retry_after_seconds=None), now)
                activity.record("error", f"codex CLI: {profile.name} — could not reach OpenAI", meta=str(exc)[:200])
                if forced_profile_id is not None:
                    # 400, not 503: codex retries any 5xx ~30 times in 24s,
                    # each one another failing connect. A pinned session has
                    # nowhere else to go, so say so once.
                    return self._codex_cli_result(400, codex_cli.error_body(
                        f"Could not reach OpenAI: {exc}", error_type="invalid_request_error"))
                continue

            filtered = _filter_openai_headers(resp_headers)
            observation = openai_observation.classify(status, filtered, now)
            if status == 429:
                # The headers may not say when the window reopens; codex's own
                # usage-limit body does.
                resets_at = codex_cli.usage_limit_resets_at(raw)
                if resets_at is not None and getattr(observation, "resets_at", None) is None:
                    observation = QuotaExhausted(resets_at=resets_at)
            credits = openai_observation.parse_credits(filtered)
            old_state = self._runtime[profile.id].state if profile.id in self._runtime else None
            with self._lock:
                if credits is not None:
                    self._record_credits(profile.id, credits)
                self._observe(profile.id, observation, now)
            self._maybe_request_usage_recheck(profile.id, observation)
            self._persist()
            if isinstance(observation, AuthInvalid) and old_state != ProfileState.AUTH_INVALID:
                activity.record("error", f"{profile.name} needs re-authentication", meta="credential rejected")
                notifications.notify_if_enabled("needs_attention", "Claude Unlimited",
                                                  f"{profile.name} needs re-authentication.", pool.settings)

            if status >= 400:
                if forced_profile_id is None and (status in (401, 402, 403, 429) or status >= 500):
                    with self._lock:
                        self._mark_profile_idle(profile.id)
                    activity.record("rotation", f"codex CLI: {profile.name} answered {status}",
                                     meta="moving the request to the next ChatGPT account")
                    continue
                return self._codex_cli_finish_error(profile, status, resp_headers, raw)

            # Served. Pin the conversation, move this path's pointer, and say so
            # when either one changed account.
            with self._lock:
                previous_current = self._codex_cli_current_id
                if forced_profile_id is None:
                    self._codex_cli_current_id = profile.id
                if thread:
                    self._codex_cli_pins.pop(thread, None)
                    self._codex_cli_pins[thread] = profile.id
                    while len(self._codex_cli_pins) > self._CODEX_CLI_PIN_CAP:
                        self._codex_cli_pins.pop(next(iter(self._codex_cli_pins)))
            if moved:
                activity.record("rotation",
                                f"codex CLI: conversation moved {self._profile_name(pool, previous_for_thread)}"
                                f" → {profile.name}" if previous_for_thread else
                                f"codex CLI: conversation continued on {profile.name}",
                                meta=f"dropped {dropped} reasoning item(s) only the previous account can read")
            elif (forced_profile_id is None and previous_current is not None
                  and previous_current != profile.id and previous_for_thread is None):
                activity.record("rotation", f"codex CLI: rotated {self._profile_name(pool, previous_current)}"
                                            f" → {profile.name}")
                notifications.notify_if_enabled("rotated", "Claude Unlimited",
                                                  f"codex CLI rotated to {profile.name}.", pool.settings)

            tee = codex_cli.UsageTee()
            quota_5h = _codex_5h_percent(resp_headers)

            def recorded(chunks, profile_id=profile.id):
                try:
                    yield from tee.wrap(chunks)
                finally:
                    if tee.usage:
                        try:
                            usage_history.record(profile_id, None, tee.model or requested_model, tee.usage,
                                                 requested_model=requested_model,
                                                 quota_5h_percent=quota_5h)
                        except Exception:
                            pass  # best-effort, never affects the response

            chunks = self._wrap_with_in_flight_clear(recorded(codex_cli.relay(resp, conn)), profile.id)
            return GatewayResult(status=status, headers=codex_cli.client_response_headers(resp_headers),
                                  body_chunks=chunks, profile_id=profile.id)

        with self._lock:
            snapshot = PoolSnapshot(profiles=list(self._runtime.values()), current_profile_id=None)
        return self._codex_cli_unavailable(load_pool(), snapshot, "rotation_attempts_exhausted", None)

    def handle_codex_cli_models(self, headers: dict, query: str,
                                forced_profile_id: Optional[str] = None) -> "GatewayResult":
        """GET /codex/v1/models: codex refreshes its model catalogue from the
        provider at startup (0.149 does it for a custom provider too). Relayed
        from one ChatGPT account — the list is the plan's, not the account's —
        so the picker and model metadata match what the user's own login sees.
        Anything that goes wrong is a 404, on which codex keeps its bundled
        list; this never affects routing state."""
        not_found = self._codex_cli_result(404, codex_cli.error_body("No model catalogue available."))
        pool = load_pool()
        if not pool.settings.codex_cli_serving:
            return not_found
        now = datetime.now(timezone.utc)
        with self._lock:
            snapshot = self._sync_snapshot(pool)
            decision = self._codex_cli_decision(pool, snapshot, now, None, set(), forced_profile_id)
        if decision.profile_id is None:
            return not_found
        profile = pool.get(decision.profile_id)
        try:
            cred = openai_bridge._refresh_if_needed(
                profile, openai_credential.decode(secret_store.get_token(profile.id)))
            status, resp_headers, resp, conn = codex_cli.send(
                cred, None, codex_cli.outbound_headers(headers, cred, None, keep_turn_state=False),
                timeout=15, method="GET", path="/models" + (f"?{query}" if query else ""))
            raw = resp.read()
            conn.close()
        except Exception as exc:  # noqa: BLE001 - a catalogue is optional
            activity.record("error", f"codex CLI: could not fetch the model list from {profile.name}",
                             meta=str(exc)[:200])
            return not_found
        if status not in (200, 304):
            return not_found
        out = codex_cli.client_response_headers(resp_headers)
        out["content-type"] = "application/json"
        return GatewayResult(status=status, headers=out, body_chunks=iter([raw]), profile_id=profile.id)

    def _codex_cli_finish_error(self, profile: Profile, status: int, resp_headers: dict,
                                raw: bytes) -> "GatewayResult":
        """An upstream error that is the request's own (a 400 for a bad body,
        say): returned to codex exactly as the backend sent it."""
        with self._lock:
            self._mark_profile_idle(profile.id)
        activity.record("error", f"codex CLI: {profile.name} answered {status}",
                         meta=raw.decode("utf-8", errors="replace")[:200])
        headers = codex_cli.client_response_headers(resp_headers)
        headers["content-type"] = {k.lower(): v for k, v in resp_headers.items()}.get(
            "content-type", "application/json")
        return GatewayResult(status=status, headers=headers, body_chunks=iter([raw]), profile_id=profile.id)

    @staticmethod
    def _models_listing_response(profile: Profile, path: str, listing: list) -> "GatewayResult":
        """Anthropic's own /v1/models wire shape, answered locally for a
        connector that has no Anthropic-compatible backend to relay to.
        Handles both the list and the /v1/models/{id} retrieve form, since
        the client SDK calls each."""
        import json as _json

        def entry(model_id: str, display_name: str) -> dict:
            return {"type": "model", "id": model_id, "display_name": display_name,
                    "created_at": "2025-01-01T00:00:00Z"}

        requested_id = path[len("/v1/models/"):].strip("/") if path.startswith("/v1/models/") else ""
        if requested_id:
            match = next(((i, n) for i, n in listing if i == requested_id), None)
            if match is None:
                payload = _json.dumps({"type": "error", "error": {
                    "type": "not_found_error", "message": f"model {requested_id!r} not found"}}).encode("utf-8")
                return GatewayResult(status=404, headers={"content-type": "application/json"},
                                      body_chunks=iter([payload]), profile_id=profile.id)
            payload = _json.dumps(entry(*match)).encode("utf-8")
        else:
            data = [entry(i, n) for i, n in listing]
            payload = _json.dumps({
                "data": data, "has_more": False,
                "first_id": data[0]["id"] if data else None,
                "last_id": data[-1]["id"] if data else None,
            }).encode("utf-8")
        return GatewayResult(status=200, headers={"content-type": "application/json"},
                              body_chunks=iter([payload]), profile_id=profile.id)

    @staticmethod
    def _codex_non_messages_response(profile: Profile, path: str, body: bytes) -> "GatewayResult":
        """A codex-kind Profile has no real Anthropic-compatible backend to
        relay these to — answer locally rather than mistranslate. Claude
        Code calls count_tokens before a real turn fairly often; a rough
        chars/4 heuristic (openly approximate, never billed against — this
        daemon does not charge for it) is far better than erroring on
        every single message this Profile serves."""
        if path == "/v1/messages/count_tokens":
            import json as _json
            try:
                parsed = _json.loads(body) if body else {}
            except _json.JSONDecodeError:
                parsed = {}
            text_len = len(_json.dumps(parsed.get("messages", []))) + len(str(parsed.get("system", "")))
            estimate = max(1, text_len // 4)
            payload = _json.dumps({"input_tokens": estimate}).encode("utf-8")
            return GatewayResult(status=200, headers={"content-type": "application/json"},
                                  body_chunks=iter([payload]), profile_id=profile.id)
        payload = b'{"type":"error","error":{"type":"not_found_error","message":"Not supported for a codex Profile."}}'
        return GatewayResult(status=404, headers={"content-type": "application/json"},
                              body_chunks=iter([payload]), profile_id=profile.id)

    def _restore_refresh_backoff(self, profile_id: str, persisted: Optional[dict],
                                  now_utc: datetime, kind: str = "oauth") -> None:
        """Carry a rate-limit refresh backoff across a restart. The needs-re-auth
        STATE already survives a restart (see _restorable_state_fields); the
        "backed off — don't re-poke the token endpoint until T" timer did not,
        because it lives on the monotonic clock, which every process starts
        fresh. So a rate-limited account re-hit the endpoint the instant the
        daemon came back, and frequent restarts (auto-update, a crash loop)
        could keep it rate-limited indefinitely — the same failure mode as
        repeated manual restarts.

        The deadline is persisted as WALL-CLOCK time (monotonic is meaningless
        in another process) and converted back to this process's monotonic clock
        here. Never raises: a malformed or missing entry restores nothing,
        exactly like a first run."""
        if not persisted:
            return
        if kind == "codex":
            # A Codex Profile's clock lives in openai_bridge, not here; same
            # fields, same wall-clock conversion, restored into that module.
            rl = persisted.get("refresh_rate_limited_streak")
            fl = persisted.get("refresh_failure_streak")
            rl = rl if isinstance(rl, int) and not isinstance(rl, bool) and rl > 0 else 0
            fl = fl if isinstance(fl, int) and not isinstance(fl, bool) and fl > 0 else 0
            remaining = None
            raw = persisted.get("refresh_backoff_until")
            if isinstance(raw, str) and raw:
                try:
                    remaining = (datetime.fromisoformat(raw) - now_utc).total_seconds()
                except (ValueError, TypeError):
                    remaining = None
            openai_bridge.restore_refresh_backoff(profile_id, remaining, rl, fl)
            return
        streak = persisted.get("refresh_rate_limited_streak")
        if isinstance(streak, int) and streak > 0:
            # Restore the streak even when the deadline has already elapsed, so
            # the NEXT rate-limited refresh keeps escalating from where it left
            # off rather than restarting the backoff at its base interval.
            self._refresh_rate_limited_streak[profile_id] = streak
        failures = persisted.get("refresh_failure_streak")   # absent in older state files
        if isinstance(failures, int) and not isinstance(failures, bool) and failures > 0:
            self._refresh_failure_streak[profile_id] = failures
        raw = persisted.get("refresh_backoff_until")
        if isinstance(raw, str) and raw:
            try:
                remaining = (datetime.fromisoformat(raw) - now_utc).total_seconds()
            except (ValueError, TypeError):
                return
            if remaining > 0:
                self._refresh_check_not_before[profile_id] = time.monotonic() + remaining

    def _refresh_attempt_due(self, profile_id: str) -> bool:
        """Whether a refresh attempt for this Profile could do anything right
        now — the same conditions _try_refresh checks before acting.

        Exists so callers can skip the expensive preamble (a keychain read per
        Profile per sync tick) rather than discovering the answer after paying
        for it. _try_refresh still re-checks, since it is what sets the clock
        and is reachable by other paths; this is a cheap pre-filter, never the
        authority."""
        not_before = self._refresh_check_not_before.get(profile_id)
        return not_before is None or time.monotonic() >= not_before

    def _try_refresh(self, profile_id: str, refresh_token: str, *,
                      cooldown: Optional[float] = None,
                      profile_name: Optional[str] = None,
                      notify_on_rejection: bool = True) -> Optional["oauth_login.LoginTokens"]:
        """The ONE place that actually calls oauth_login.refresh_access_token
        — shared by _maybe_refresh_credential (the per-request path, called
        from inside handle() for whichever Profile choose() just picked) and
        _maybe_check_oauth_credential (the sync-driven path, covering idle
        and AUTH_INVALID Profiles) specifically so they share ONE per-Profile
        backoff clock (self._refresh_check_not_before), not two independent
        ones.

        This is load-bearing. With independent clocks, one path can take a
        429 and the other retries the same Profile moments later, unaware.
        Whichever path hits a 429 first must block BOTH until the backoff
        clears. Returns None (not an exception) when still within the
        backoff window — that is a normal, silent "not due yet" outcome,
        never logged as a failure by either caller. Raises
        oauth_login.OAuthLoginError, unchanged, for a real (non-throttled)
        failure — already logged here, and already backed off.

        EVERY failure escalates the wait, not only a 429 (issue #10): a grant
        that died while the account sat idle used to be retried on the plain
        60s cooldown forever, silently. See refresh_backoff."""
        now = time.monotonic()
        # Claim the slot atomically. Anthropic ROTATES the refresh token on
        # use, so two threads refreshing the same Profile at once send the same
        # token: one succeeds and consumes it, the other replays a token that
        # no longer exists. That earns 429s from the token endpoint and can
        # invalidate the grant outright — which is exactly how an account that
        # was refreshing fine ends up needing a manual re-auth.
        #
        # The check and the write have to happen together. Reading not_before,
        # deciding, and then writing it is a check-then-act that both threads
        # can pass.
        with self._refresh_lock:
            if profile_id in self._refresh_in_progress:
                return None   # another thread is already refreshing this one
            not_before = self._refresh_check_not_before.get(profile_id)
            if not_before is not None and now < not_before:
                return None
            self._refresh_check_not_before[profile_id] = now + (
                cooldown if cooldown is not None else self._REFRESH_CHECK_COOLDOWN_SECONDS)
            self._refresh_in_progress.add(profile_id)
        try:
            tokens = oauth_login.refresh_access_token(refresh_token)
        except oauth_login.OAuthLoginError as exc:
            if exc.status_code == 429:
                # Anthropic's own rate limiter, not a dead credential —
                # retrying this every _REFRESH_CHECK_COOLDOWN_SECONDS (60s)
                # never let the window actually clear, since each attempt
                # is itself another strike against the same limiter. Back
                # off much further before ANY path tries this Profile again.
                streak = self._refresh_rate_limited_streak.get(profile_id, 0) + 1
                self._refresh_rate_limited_streak[profile_id] = streak
                wait = min(self._RATE_LIMIT_BACKOFF_SECONDS * (2 ** (streak - 1)),
                            self._RATE_LIMIT_BACKOFF_CEILING_SECONDS)
                self._refresh_check_not_before[profile_id] = now + wait
                if streak == self._RATE_LIMITED_REFRESHES_BEFORE_WARNING:
                    # Once, on the crossing — not on every attempt after it,
                    # which would fill the Activity log with the same line.
                    activity.record(
                        "error", "Automatic token refresh keeps being rate limited",
                        meta=(f"{profile_id}: {streak} times in a row. Still retrying, now every "
                              f"{int(self._RATE_LIMIT_BACKOFF_CEILING_SECONDS // 3600)}h — "
                              "`claude-unlimited reauth` recovers it immediately."))
            else:
                self._note_refresh_failure(profile_id, exc, now, cooldown, profile_name,
                                           notify_on_rejection)
            raise
        finally:
            with self._refresh_lock:
                self._refresh_in_progress.discard(profile_id)
        self._refresh_rate_limited_streak.pop(profile_id, None)
        self._refresh_failure_streak.pop(profile_id, None)
        return tokens

    def _note_refresh_failure(self, profile_id: str, exc: "oauth_login.OAuthLoginError", now: float,
                              cooldown: Optional[float], profile_name: Optional[str],
                              notify_on_rejection: bool) -> None:
        """A non-429 refresh failure: escalate the backoff, log it, and — the
        first time the endpoint rejects the grant outright — tell the person,
        since the access token will stop working when it expires."""
        streak = self._refresh_failure_streak.get(profile_id, 0) + 1
        self._refresh_failure_streak[profile_id] = streak
        base = cooldown if cooldown is not None else self._REFRESH_CHECK_COOLDOWN_SECONDS
        wait = refresh_backoff.failure_wait(exc.status_code, streak, base, self._RATE_LIMIT_BACKOFF_SECONDS)
        self._refresh_check_not_before[profile_id] = now + wait
        name = profile_name or profile_id
        if refresh_backoff.worth_logging(streak):
            activity.record("error", f"{name} — token refresh failed",
                             meta=f"{refresh_backoff.describe(exc.status_code, streak, wait)} ({str(exc)[:160]})")
        if streak == 1 and notify_on_rejection and refresh_backoff.is_rejection(exc.status_code):
            try:
                notifications.notify_if_enabled(
                    "needs_attention", "Claude Unlimited",
                    f"{name}: renewing its sign-in was refused — run `claude-unlimited reauth`.",
                    load_pool().settings)
            except Exception:
                pass   # a notification must never break a refresh path

    def _maybe_refresh_credential(self, profile: Profile, stored: str) -> str:
        """Proactively refreshes an OAuth Profile's access token before it's
        used, if it's within oauth_credential.EXPIRING_SOON_BUFFER_MS of its
        known expiry (or already past it) and a refresh_token is on hand.
        Without this, every OAuth Profile eventually goes stale and needs a
        full manual re-auth no matter how "healthy" it looked a moment ago —
        the access token itself has a real, usually short, expiry, and
        nothing else refreshes it — so a Profile can look healthy and still
        fail on its very next request.

        Always returns the actual bare access token to use — NEVER the raw
        `stored` string as-is, which for a Profile using the new blob shape
        (anything with a refresh_token) is a JSON object, not a token; using
        it directly as the Bearer credential would send Anthropic garbage.

        A silent no-op for a Profile with no known expiry (covers every
        Profile that predates this feature, and any manually pasted token,
        which never has a refresh_token at all), if still within
        _try_refresh's shared backoff window, or if the refresh itself
        fails — that falls through to sending the possibly-stale but still
        real access token exactly as before this existed, so a real 401
        still correctly lands the Profile on AUTH_INVALID rather than this
        method blocking the request pipeline on a refresh failure."""
        cred = oauth_credential.decode(stored)
        if not cred.refresh_token or not oauth_credential.is_expiring_soon(cred):
            return cred.access_token
        try:
            refreshed = self._try_refresh(profile.id, cred.refresh_token, profile_name=profile.name)
        except oauth_login.OAuthLoginError:
            # _try_refresh has already recorded it in Activity (it used to be
            # silent here, indistinguishable from "nothing tried").
            return cred.access_token
        if refreshed is None:
            return cred.access_token  # still within the shared backoff window — not due yet
        try:
            profile_repo.update_credential(
                profile.id, refreshed.access_token,
                refresh_token=refreshed.refresh_token or cred.refresh_token,
                expires_at=refreshed.expires_at,
            )
        except Exception as exc:
            # Anthropic ROTATES the refresh token on every refresh: the one we
            # just spent is now dead server-side. If persisting the replacement
            # fails we are left holding an invalidated token, every future
            # refresh fails with invalid_grant, and the Profile ends up needing
            # a full manual re-auth. This used to be a bare `pass`, so the one
            # failure that causes exactly that left no trace anywhere and had
            # to be inferred. This request still succeeds on the
            # token we just got — but say so loudly, because it is the last
            # one that will work.
            activity.record("error", f"{profile.name} — could not save refreshed credential",
                             meta=f"re-auth will be required: {str(exc)[:160]}")
            notifications.notify_if_enabled(
                "needs_attention", "Claude Unlimited",
                f"{profile.name}: could not save its refreshed login — it will need re-authentication.",
                load_pool().settings)
        return refreshed.access_token

    def force_active(self, profile_id: str) -> bool:
        """The Dashboard's "Take over" action: immediately makes this
        Profile the active one for the next request, bypassing normal
        priority/threshold/rotation selection. Resets its live state to
        ELIGIBLE regardless of what it was (DRAINING past its threshold,
        EXHAUSTED, COOLDOWN, even AUTH_INVALID) — the whole point of a
        deliberate manual override is to try it right now anyway; the very
        next real request is the honest test of whether it's actually
        usable, and a stale state that doesn't reflect reality just gets
        re-observed correctly from that real response.

        Returns False without doing anything for a disabled Profile
        (respects that as explicit user intent — a "Take over" action
        implicitly re-enabling it would be surprising) or one that no
        longer exists. True on success."""
        with self._lock:
            pool = load_pool()
            profile = pool.get(profile_id)
            if profile is None or not profile.enabled:
                return False
            snapshot = self._sync_snapshot(pool)
            self._runtime = {rt.profile_id: rt for rt in snapshot.profiles}
            rt = self._runtime.get(profile_id)
            if rt is None:
                return False
            self._runtime[profile_id] = replace(rt, state=ProfileState.ELIGIBLE,
                                                  cooldown_until=None, resets_at=None)
            previous_profile_id = self._current_profile_id
            self._current_profile_id = profile_id
            # Hold it against concurrent traffic. The shared pointer alone is
            # not enough: with hundreds of requests in flight, ones that had
            # already picked another account finish and set the pointer back,
            # so a Take Over during a burst flapped between accounts within
            # the same second. The override stands until the user takes over
            # something else, or this Profile stops being usable.
            self._manual_profile_id = profile_id
            # Take Over is an explicit "I'm on THIS one now" — clear the
            # profile it moved away from so it doesn't keep showing "Used now"
            # for the rest of its grace window (in_flight_ids()), exactly as a
            # rotation switch does (handle()'s _last_active.pop). A profile with
            # a request GENUINELY still in flight (another pinned terminal)
            # stays lit via self._in_flight — this only drops the idle grace.
            if previous_profile_id and previous_profile_id != profile_id:
                self._last_active.pop(previous_profile_id, None)
        self._persist()
        activity.record("rotation", f"{profile.name} manually taken over",
                         meta="overrides rotation/threshold")
        return True

    _MAX_REJECTED_MODELS = 64

    @staticmethod
    def _rejection_key(profile: Profile) -> tuple:
        # Keyed by the endpoint too: pointing the Profile at another server
        # must not carry over what the old one refused.
        return (profile.id, profile.base_url or "")

    def _remember_rejected_model(self, profile: Profile, model: Optional[str]) -> None:
        """This endpoint does not serve `model`. Bounded, and in memory only:
        a restart re-learns it with one 404, and an endpoint that gains the
        model back is not held to an answer it gave last week."""
        if not model:
            return
        with self._lock:
            known = self._models_rejected_by.setdefault(self._rejection_key(profile), set())
            if len(known) < self._MAX_REJECTED_MODELS:
                known.add(model)

    def _default_model_body(self, profile: Profile, body: bytes) -> Optional[bytes]:
        """The body rewritten to the Profile's default_model, when this
        endpoint has already refused the model the client asked for. None
        when there is nothing known to act on — a multi-model gateway keeps
        serving whatever it is asked for."""
        if profile.kind != "api" or not profile.default_model:
            return None
        requested = request_model(body)
        if requested is None or requested == profile.default_model:
            return None
        with self._lock:
            known = self._models_rejected_by.get(self._rejection_key(profile))
        if not known or requested not in known:
            return None
        return rewrite_model(body, profile.default_model)

    def _maybe_retry_with_default_model(self, profile: Profile, credential: str, method: str, path: str,
                                          headers: dict, body: bytes, now: datetime, *, parity=None):
        """Retries ONCE against profile.default_model instead of whatever
        model the client actually asked for — called only when the first
        attempt already failed with a status in _MODEL_FALLBACK_STATUS_CODES
        (see handle()). A real scenario this fixes: running `/model` in a
        Claude Code session routed through an API-kind Profile whose key
        doesn't have that model — before this, the failure got surfaced (or,
        pre the classify() 401/403 fix, actively mis-surfaced as "needs
        re-authentication") instead of just falling back to the model that
        Profile was actually configured for.

        Returns None (nothing to retry) when the body has no "model" field,
        or when it already IS default_model — retrying with an identical
        body would just reproduce the exact same failure. On a network
        error during the retry itself, also returns None (caller keeps the
        original failed response/observation — a second network failure is
        not this method's problem to solve)."""
        requested_model = request_model(body)
        if requested_model is None or requested_model == profile.default_model:
            return None
        retry_body = rewrite_model(body, profile.default_model)
        # Effort must match the model we're NOW sending (default_model), not the
        # one that failed — carrying the original's effort could push a value
        # default_model rejects (e.g. onto a Haiku-class default). Rebuilt from
        # the original body so build_upstream_request injects the right one.
        retry_effort = openai_models.claude_effort_for(profile.default_model, parity)
        try:
            retry_req = build_upstream_request(profile, credential, method, path, headers, retry_body,
                                               claude_effort=retry_effort)
        except ValueError:
            return None
        try:
            retry_resp = self._transport(retry_req)
        except (OSError, http.client.HTTPException):
            return None
        retry_observation = classify(retry_resp.status, filter_response_headers(retry_resp.headers), now)
        activity.record("config", f"{profile.name} — retried with its default model",
                         meta=f"{requested_model} unavailable, used {profile.default_model} instead")
        return retry_resp, retry_observation

    def _announce_rotation(self, pool: Pool, previous_profile_id: str, profile: Profile, reason: str) -> None:
        """The Activity line and notification for a pointer move. Named by
        cause: "Rotated" reads as "the account ran out", which is wrong for
        an account that only spent its Fable week and asked to be left."""
        prev_name = self._profile_name(pool, previous_profile_id)
        if reason == "window_handover":
            activity.record("rotation", f"{prev_name} cannot hold this conversation — handed over to {profile.name}",
                             meta="the account is not out of quota; the conversation outgrew its backend's window")
            notifications.notify_if_enabled("rotated", "Claude Unlimited",
                                              f"{prev_name} cannot hold this conversation — handed over to {profile.name}.",
                                              pool.settings)
            return
        if reason == "fable_limit_handover":
            activity.record("rotation", f"{prev_name} has spent its Fable weekly limit — handed over to {profile.name}",
                             meta="the account is not out of quota; its Fable week is, and it is set to leave")
            notifications.notify_if_enabled("rotated", "Claude Unlimited",
                                              f"{prev_name} has spent its Fable weekly limit — handed over to {profile.name}.",
                                              pool.settings)
            return
        activity.record("rotation", f"Rotated {prev_name} → {profile.name}")
        notifications.notify_if_enabled("rotated", "Claude Unlimited",
                                          f"Rotated {prev_name} → {profile.name}.", pool.settings)

    def _note_fable_limit_served_anyway(self, pool: Pool, profile_id: str, now: datetime, how: str) -> None:
        """One Activity line per account per spent Fable week for a request
        that is served on it ANYWAY — a pin that is honoured, or a pool with
        nowhere else to go. _sync_snapshot forgets the note once the account
        is no longer spent. Safe with or without self._lock: it only touches
        the noted set and writes Activity."""
        rt = self._runtime.get(profile_id)
        if rt is None or not fable_spent(rt, now) or profile_id in self._fable_limit_noted:
            return
        self._fable_limit_noted.add(profile_id)
        activity.record("rotation", f"{self._profile_name(pool, profile_id)} has spent its Fable weekly limit",
                         meta=how)

    def _forced_decision(self, pool: Pool, forced_profile_id: str,
                         now: Optional[datetime] = None,
                         fit: Optional[RequestFit] = None) -> RoutingDecision:
        """Routing for a `forced_profile_id` request (see handle()) — always
        picks exactly that Profile, bypassing priority/threshold ranking the
        same way force_active() does, EXCEPT for AUTH_INVALID: force_active()
        is a one-shot manual click where "try it anyway, the next response
        is the honest test" is the right call, but a forced session hits
        this on every single request for as long as it's pinned (session
        tokens live up to session_tokens.SESSION_TOKEN_TTL) — retrying a
        credential already known to be dead on every request would just
        waste a round trip and surface a raw upstream 401 instead of one
        clear local message. Caller must already hold self._lock and have
        refreshed self._runtime from a current snapshot."""
        profile = pool.get(forced_profile_id)
        if profile is None:
            return RoutingDecision(profile_id=None, reason="forced_profile_missing")
        if not profile.enabled:
            return RoutingDecision(profile_id=None, reason="forced_profile_disabled")
        rt = self._runtime.get(forced_profile_id)
        if rt is not None and rt.budget_unavailable:
            return RoutingDecision(profile_id=None, reason="provider_budget_unavailable")
        if rt is not None and rt.state == ProfileState.AUTH_INVALID:
            return RoutingDecision(profile_id=None, reason="forced_profile_needs_reauth")
        if rt is not None and not fits(rt, fit):
            # Still honoured — never substituted — but a request known to
            # overflow this account's window buys nothing by being sent: the
            # backend's error would be one the client cannot recover from.
            # handle() answers "prompt is too long" instead, the session
            # compacts, and stays on the account it was pinned to.
            return RoutingDecision(profile_id=None, reason="no_profile_fits_request")
        if rt is not None and now is not None and must_leave(rt, now):
            # The pin is HONOURED — never silently substituted, which is the
            # whole point of pinning. The user simply gets the
            # provider's own limit error on Fable, and one Activity line so it
            # is not a mystery why a pinned session started failing.
            self._note_fable_limit_served_anyway(pool, forced_profile_id, now,
                                                 "pinned session (cu code --profile) — served anyway, not rotated")
        return RoutingDecision(profile_id=forced_profile_id, reason="forced")

    def _note_assumed_windows(self, pool: Pool, guard: "RequestGuard") -> None:
        """One Activity line per GPT id the guard had to ASSUME a window for,
        so an id missing from gpt_windows' table is never a silent guess.
        Safe without self._lock: a set add and an Activity write."""
        for profile_id, info in guard.windows.items():
            if not info.assumed or info.model in self._window_assumed_noted:
                continue
            self._window_assumed_noted.add(info.model)
            activity.record("config", f"{self._profile_name(pool, profile_id)} — assuming a {info.window:,}-token "
                                      f"window for {info.model}",
                             meta=f"{info.model} is not in gpt_windows.py ({info.backend} backend); "
                                  f"add it there and re-run scripts/check_gpt_windows.py")

    # Re-announce the same session's "prompt is too long" at most this often.
    _CAPACITY_NOTE_INTERVAL_SECONDS = 600.0

    def _prompt_too_long_result(self, pool: Pool, snapshot: PoolSnapshot, guard: "RequestGuard",
                                headers: dict, branch: Optional[tuple],
                                forced_profile_id: Optional[str]) -> GatewayResult:
        """The guard's terminal answer: HTTP 400 in Anthropic's own error
        envelope, wording byte-exact to what Claude Code's reactive
        compaction parses (gpt_windows.prompt_too_long_message). The limit
        quoted is the largest budget among the accounts this request was
        allowed to use, so the client compacts by a real gap."""
        if forced_profile_id is not None:
            considered = [forced_profile_id]
        elif self._manual_profile_id is not None and self._manual_profile_id in guard.windows:
            considered = [self._manual_profile_id]
        else:
            considered = [rt.profile_id for rt in snapshot.profiles
                          if rt.state == ProfileState.ELIGIBLE and rt.profile_id in guard.windows]
        budgets = [guard.windows[pid].budget for pid in considered if pid in guard.windows]
        if not budgets:
            budgets = [info.budget for info in guard.windows.values()] or [gpt_windows.MIN_BUDGET]
        maximum = max(budgets)
        estimate = guard.fit.estimated_tokens
        message = gpt_windows.prompt_too_long_message(estimate, maximum)

        key = (forced_profile_id, branch)
        last = self._capacity_noted_at.get(key)
        if last is None or _pin_clock() - last >= self._CAPACITY_NOTE_INTERVAL_SECONDS:
            cutoff = _pin_clock() - self._CAPACITY_NOTE_INTERVAL_SECONDS
            self._capacity_noted_at = {k: v for k, v in self._capacity_noted_at.items() if v > cutoff}
            self._capacity_noted_at[key] = _pin_clock()
            names = ", ".join(self._profile_name(pool, pid) for pid in considered) or "no account"
            how = ("pinned session (cu code --profile) — not rotated" if forced_profile_id is not None
                   else "Take over — not rotated" if self._manual_profile_id is not None
                   else "no eligible account can hold it")
            activity.record("rotation", f"Conversation exceeds {names}'s window — asked Claude Code to compact",
                             meta=f"~{estimate:,} estimated tokens > {maximum:,}; {how}; "
                                  f"client={_client_label(headers)}")
        return GatewayResult(status=400, headers={}, body_chunks=None, profile_id=None,
                              error="request_exceeds_every_window", error_detail=message)

    def _persist(self) -> None:
        """Best-effort snapshot of the Dashboard-visible runtime fields to
        disk (runtime_state.py) — never allowed to affect a real request,
        so any failure here is swallowed, not raised."""
        with self._lock:
            current_profile_id = self._current_profile_id
            # A rate-limit refresh backoff is worth carrying across a restart —
            # see _restore_refresh_backoff. The deadline lives on the monotonic
            # clock, so translate it to wall-clock here; only a Profile with an
            # active rate-limited streak is persisted, so the ordinary 60s
            # refresh throttle never leaks into the persisted state.
            now_monotonic = time.monotonic()
            now_utc = datetime.now(timezone.utc)
            backoff: dict[str, tuple] = {}
            for pid in self._runtime:
                streak = self._refresh_rate_limited_streak.get(pid, 0)
                failures = self._refresh_failure_streak.get(pid, 0)
                until = None
                if streak > 0 or failures > 0:
                    not_before = self._refresh_check_not_before.get(pid)
                    if not_before is not None and not_before - now_monotonic > 0:
                        until = (now_utc + timedelta(seconds=not_before - now_monotonic)).isoformat()
                if not (streak > 0 or failures > 0):
                    # A Codex Profile keeps its clock in openai_bridge.
                    remaining, streak, failures = openai_bridge.export_refresh_backoff(pid, now_monotonic)
                    if remaining is not None:
                        until = (now_utc + timedelta(seconds=remaining)).isoformat()
                backoff[pid] = (until, streak if streak > 0 else None, failures if failures > 0 else None)
            profiles = {
                pid: {
                    "last_usage_percent": rt.last_usage_percent,
                    "resets_at": rt.resets_at.isoformat() if rt.resets_at else None,
                    "last_usage_percent_7d": rt.last_usage_percent_7d,
                    "resets_at_7d": rt.resets_at_7d.isoformat() if rt.resets_at_7d else None,
                    "window_label": rt.window_label,
                    "window_label_7d": rt.window_label_7d,
                    "model_usage": [
                        {"name": w.name, "percent": w.percent,
                         "resets_at": w.resets_at.isoformat() if w.resets_at else None,
                         "active": w.active}
                        for w in rt.model_usage
                    ],
                    # Restored so a restart doesn't silently present a Profile
                    # as healthy when it is not. See _restorable_state_fields
                    # for which states survive and which are re-derived.
                    "state": rt.state.value if hasattr(rt.state, "value") else str(rt.state),
                    "cooldown_until": rt.cooldown_until.isoformat() if rt.cooldown_until else None,
                    "budget_unavailable": rt.budget_unavailable,
                    # See _restore_refresh_backoff: keeps a rate-limited account
                    # from re-poking the token endpoint the moment the daemon
                    # restarts.
                    "refresh_backoff_until": backoff[pid][0],
                    "refresh_rate_limited_streak": backoff[pid][1],
                    # A rejected grant's escalation (issue #10), so a restart
                    # does not drop it back to the first step.
                    "refresh_failure_streak": backoff[pid][2],
                    "credits_has": rt.credits_has,
                    "credits_balance": rt.credits_balance,
                }
                for pid, rt in self._runtime.items()
            }
        try:
            runtime_state.save(current_profile_id, profiles)
        except Exception:
            pass

    @staticmethod
    def _wrap_with_usage_capture(chunks, resp_headers: dict, profile_id: str, project_id: Optional[str],
                                  requested_model: Optional[str] = None,
                                  eco_stats: Optional["eco.CompactionStats"] = None,
                                  sent_bytes: int = 0,
                                  quota_5h_percent: Optional[float] = None):
        """Tees the response body through UsageCapture (see its module
        docstring for the safety invariant: every byte forwarded exactly
        unchanged) and records one usage_history event as soon as the
        capture has what it needs.

        Recording lives in a `finally`, not directly after the `yield from` —
        verified as a real, live bug: the real `claude` CLI routinely closes
        its socket right after it has parsed what it needs, before the
        daemon's write loop finishes draining this generator. That raises
        BrokenPipeError/ConnectionResetError in daemon.py's write loop, which
        catches it and returns — abandoning this generator without ever
        reaching code placed directly after `yield from`, even though
        parsing (a side effect of pulling each chunk, which already
        happened) had already captured a complete model+usage. Confirmed via
        a real captured request: project attribution recorded 12 real
        requests while usage_history recorded 0, because project attribution
        happens before any bytes are streamed while this happens after.
        `finally` runs on that same abandonment too — CPython closes a
        garbage-collected generator by throwing GeneratorExit into it at its
        suspension point, which unwinds through `finally` normally — so this
        now records real capability actually used, not just the lucky case
        where a client happens to keep reading until the literal last byte."""
        if chunks is None:
            return chunks
        content_type = {k.lower(): v for k, v in resp_headers.items()}.get("content-type")
        capture = usage_tracking.UsageCapture()

        def generator():
            try:
                yield from capture.wrap(chunks, content_type)
            finally:
                if capture.model and capture.usage:
                    try:
                        # Savings land on the SAME row as the token counts, so
                        # "what did ECO save" is answerable per request rather
                        # than as a floating total. Tokens are calibrated from
                        # what this very request was billed; bytes are exact.
                        saved = eco_stats.bytes_saved if eco_stats else 0
                        billed = (int(capture.usage.get("input_tokens") or 0)
                                  + int(capture.usage.get("cache_creation_input_tokens") or 0)
                                  + int(capture.usage.get("cache_read_input_tokens") or 0))
                        usage_history.record(
                            profile_id, project_id, capture.model, capture.usage,
                            requested_model=requested_model,
                            eco_bytes_saved=saved or None,
                            eco_tokens_saved=usage_history.calibrated_tokens_saved(
                                saved, sent_bytes, billed) if saved else None,
                            eco_mode=_eco_mode_of(eco_stats) if saved else None,
                            speech_mode=_speech_level_of(eco_stats),
                            quota_5h_percent=quota_5h_percent)
                    except Exception:
                        pass  # usage history is best-effort — must never affect a real request

        return generator()

    # ---- branch pinning (call with self._lock held) ------------------------

    def _live_pin(self, key: tuple, attempted: set,
                  snapshot: Optional[PoolSnapshot] = None, now: Optional[datetime] = None,
                  fit: Optional[RequestFit] = None) -> Optional[str]:
        """The account this branch is pinned to, if that pin is still usable:
        not expired, the Profile still ELIGIBLE, not already tried and failed
        on this request, and not an account that has asked to be left because
        its Fable week is spent (issue #2). Anything else is treated as no
        pin, so the caller re-assigns (and the re-assignment overwrites the
        stale one) — which is how the pin MOVES rather than the one request
        being diverted: the work and its prompt cache stay together on the
        new account."""
        pin = self._branch_pins.get(key)
        if pin is None:
            return None
        if _pin_clock() - pin.last_touch >= BRANCH_PIN_TTL_SECONDS:
            del self._branch_pins[key]  # lazy expiry, at the request boundary
            return None
        if pin.profile_id in attempted:
            return None
        runtime = self._runtime.get(pin.profile_id)
        if runtime is None or runtime.state != ProfileState.ELIGIBLE:
            return None
        if not fits(runtime, fit):
            # Unconditionally, unlike the Fable case below: staying is a
            # guaranteed failure, so the pin moves for good. If nowhere else
            # can hold it either, the fallthrough answers "prompt too long".
            return None
        if now is not None and must_leave(runtime, now):
            # Only give the pin up when somewhere else can actually take the
            # branch. Moving it to an account that must equally be left would
            # cost it its warm cache and change nothing.
            others = [rt for rt in (snapshot.profiles if snapshot is not None else ())
                      if rt.profile_id != pin.profile_id and rt.state == ProfileState.ELIGIBLE
                      and rt.automatic and not must_leave(rt, now)]
            if others:
                return None
        pin.last_touch = _pin_clock()
        return pin.profile_id

    def _remember_pin(self, key: tuple, profile_id: str, parent_agent_id: Optional[str],
                      distributed: bool = False) -> None:
        now = _pin_clock()
        existing = self._branch_pins.get(key)
        if existing is not None:
            if existing.profile_id != profile_id:
                # "On this account for 42m" must not count the time the agent
                # spent on the account it just failed over from.
                existing.created_at = now
            existing.profile_id = profile_id
            existing.last_touch = now
            existing.distributed = distributed
            return
        if len(self._branch_pins) >= BRANCH_PIN_CAP:
            oldest = min(self._branch_pins, key=lambda k: self._branch_pins[k].last_touch)
            del self._branch_pins[oldest]
        self._branch_pins[key] = BranchPin(profile_id=profile_id, last_touch=now, created_at=now,
                                            agent_id=key[1], parent_agent_id=parent_agent_id,
                                            distributed=distributed)

    def _branch_counts(self) -> dict:
        """Live pins per Profile — the load half of choose_for_new_branch's
        (pinned + 1) / weight, so branches keep spreading instead of all
        landing on the heaviest account."""
        counts: dict = {}
        cutoff = _pin_clock() - BRANCH_PIN_TTL_SECONDS
        for pin in self._branch_pins.values():
            if pin.last_touch > cutoff:
                counts[pin.profile_id] = counts.get(pin.profile_id, 0) + 1
        return counts

    def _forced_subagent_profile(self, pool: Pool):
        """The Profile flagged 'always use for subagents', if any is enabled.
        config.save_pool guarantees at most one."""
        return next((p for p in pool.profiles
                     if getattr(p, "forced_for_subagents", False) and p.enabled), None)

    def _branch_modes_apply(self, pool: Pool, distribute: bool, is_subagent: bool) -> bool:
        """Whether any per-branch routing mode could route this request — the
        same conditions _branch_decision() checks before falling through."""
        return bool(distribute or pool.settings.distribute_sessions_default
                    or (is_subagent and self._forced_subagent_profile(pool) is not None))

    @staticmethod
    def _app_pinned(headers: dict) -> bool:
        """The caller named its own branch (APP_SESSION_HEADER): route it per
        branch — one account per worker, kept while that account is usable."""
        return project_attribution.app_session_id(headers) is not None

    # How long the whole pool must have been idle before the rotation pointer
    # is allowed to move back to a higher-priority account (issue #4). Long
    # enough that no session is plausibly mid-task: moving back throws away a
    # warm prompt cache, which is the reason choose() is sticky in the first
    # place, so the return must cost a session nothing.
    _RETURN_TO_PREFERRED_IDLE_SECONDS = 600.0  # 10 minutes

    def _maybe_return_to_preferred(self, pool: Pool, snapshot: PoolSnapshot,
                                   now: Optional[datetime] = None,
                                   fit: Optional[RequestFit] = None) -> PoolSnapshot:
        """Issue #4: after a failover the pool stays on the fallback for as
        long as it works, even once the preferred account's window has reset,
        because choose() is sticky while the current Profile is ELIGIBLE. That
        stickiness is deliberate — it protects the prompt cache and, with
        branch pinning, keeps live agents where they are — so the return is
        opt-in and off by default. Subscription-to-subscription moves wait
        for an idle pool; a paid API fallback returns to an available
        subscription at a new request boundary without disturbing streams.

        Caller holds self._lock. Returns the snapshot to route on; the only
        thing it ever changes is the rotation POINTER, which choose() then
        re-sorts by priority. It moves no branch pin: a pinned branch keeps
        its own account until that account stops serving it, unchanged.
        """
        if not pool.settings.return_to_preferred:
            return snapshot
        # "Take over" is an explicit, standing user choice — it outranks a
        # preference the user set once, the same way it outranks rotation.
        if self._manual_profile_id is not None:
            return snapshot
        current_id = snapshot.current_profile_id
        if current_id is None:
            return snapshot
        current = next((rt for rt in snapshot.profiles if rt.profile_id == current_id), None)
        candidates = [rt for rt in snapshot.profiles
                      if rt.state == ProfileState.ELIGIBLE and rt.automatic
                      and fits(rt, fit) and not must_leave(rt, now or datetime.now(timezone.utc))]
        if not candidates:
            return snapshot
        preferred = min(candidates, key=lambda rt: rt.priority)
        if preferred.profile_id == current_id:
            return snapshot
        # Only ever move UP the priority order. If the pool is on the fallback
        # because the preferred account is spent, the preferred one is not a
        # candidate at all and this does nothing; if the current account is
        # simply the higher-priority one already, there is nothing to return
        # to.
        if current is not None and preferred.priority >= current.priority:
            return snapshot
        current_profile = pool.get(current_id)
        preferred_profile = pool.get(preferred.profile_id)
        subscription_return = (current_profile is not None and current_profile.kind == "api"
                               and preferred_profile is not None and preferred_profile.kind == "oauth")
        idle_for = self._seconds_since_last_activity_locked()
        if not subscription_return and idle_for is not None and idle_for < self._RETURN_TO_PREFERRED_IDLE_SECONDS:
            return snapshot
        self._current_profile_id = None
        name = self._profile_name(pool, preferred.profile_id)
        activity.record("rotation", f"returning to {name}",
                         meta=("subscription available again — routing new requests" if subscription_return
                               else "higher-priority account is available again and the pool is idle"))
        return PoolSnapshot(profiles=snapshot.profiles, current_profile_id=None)

    def _manual_choice(self, pool: Pool, snapshot: PoolSnapshot, now: datetime,
                       fit: Optional[RequestFit] = None) -> RoutingDecision:
        """Global (non-branch) routing: a standing "Take over" wins over the
        rotation pointer while its Profile is still ELIGIBLE; otherwise this is
        the unchanged sticky choose(). Cleared as soon as that Profile stops
        being usable, so a manual override can never strand the pool."""
        manual = self._manual_profile_id
        if manual is not None:
            chosen = next((rt for rt in snapshot.profiles if rt.profile_id == manual), None)
            if chosen is not None and chosen.state == ProfileState.ELIGIBLE:
                if not fits(chosen, fit):
                    # Honoured, not substituted — but not sent either (see
                    # _forced_decision): the client is asked to compact.
                    return RoutingDecision(profile_id=None, reason="no_profile_fits_request")
                # A standing "Take over" is honoured even when that account
                # has spent its Fable week and would otherwise leave: the user
                # named it. They get the provider's own error, not a silent
                # substitution — and one Activity line saying so.
                if must_leave(chosen, now):
                    self._note_fable_limit_served_anyway(pool, manual, now,
                                                         "Take over — served anyway, not rotated")
                return RoutingDecision(profile_id=manual, reason="manual_override")
            self._manual_profile_id = None
        return choose(snapshot, now, fit)

    def _record_branch_move(self, pool: Pool, from_id: str, to_id: str, why: str = "unavailable") -> None:
        """A pinned agent had to leave its account: it stopped being eligible,
        failed this request, or spent its Fable week and is set to be left
        (`why == "fable_limit"`). Branch-routed traffic never moves the shared
        pointer (see _BRANCH_ROUTED_REASONS), so without this a pool running
        entirely per branch would never log or announce a switch at all.
        Call WITHOUT self._lock held — activity and notifications do I/O."""
        from_name, to_name = self._profile_name(pool, from_id), self._profile_name(pool, to_id)
        cause = (f"{from_name} has spent its Fable weekly limit" if why == "fable_limit"
                 else f"the conversation outgrew {from_name}'s window" if why == "outgrew_window"
                 else f"{from_name} stopped being available")
        activity.record("rotation", f"Agent moved {from_name} → {to_name}", meta=cause)
        with self._lock:
            last = self._branch_move_notified_at.get(from_id)
            due = last is None or _pin_clock() - last >= BRANCH_MOVE_NOTIFY_INTERVAL_SECONDS
            if due:
                self._branch_move_notified_at[from_id] = _pin_clock()
        if due:
            notifications.notify_if_enabled("rotated", "Claude Unlimited",
                                              f"Agents moving {from_name} → {to_name}.", pool.settings)

    def _branch_decision(self, pool: Pool, snapshot: PoolSnapshot, now: datetime, key: Optional[tuple],
                         is_subagent: bool, parent_agent_id: Optional[str], attempted: set,
                         distribute: bool, may_create_pin: bool,
                         moves: Optional[list] = None, app_pinned: bool = False,
                         fit: Optional[RequestFit] = None) -> RoutingDecision:
        """Routing for per-branch modes, in precedence order. Falls through to
        the unchanged global sticky `choose()` whenever neither mode applies —
        so a non-Claude-Code client, or an unidentifiable request, behaves
        exactly as it did before this feature existed."""
        # `distribute_sessions_default` makes every session behave as if it had
        # been launched with --distribute. OR-ed, never assigned: the setting
        # can only turn distribution on, so a session that asked for it still
        # gets it while the setting is off. Read per request (the pool is
        # already loaded), so toggling it takes effect without a restart.
        distribute = distribute or pool.settings.distribute_sessions_default
        forced_profile = self._forced_subagent_profile(pool) if is_subagent else None
        if key is None or not (distribute or app_pinned or forced_profile is not None):
            return self._manual_choice(pool, snapshot, now, fit)

        pinned = self._live_pin(key, attempted, snapshot, now, fit)
        if pinned is not None:
            # Same account as last turn -> its prompt cache is still warm.
            return RoutingDecision(profile_id=pinned, reason="branch_pinned")
        # A pin that is still in the map here is live but unusable (its
        # Profile isn't ELIGIBLE, or failed this request): re-assigning it is a
        # move, reported through `moves`. Expired pins were already dropped.
        prior = self._branch_pins.get(key)

        def _note_move(to_id: Optional[str]) -> None:
            if moves is not None and may_create_pin and prior is not None and to_id and to_id != prior.profile_id:
                prior_rt = self._runtime.get(prior.profile_id)
                if prior_rt is not None and prior_rt.state == ProfileState.ELIGIBLE and not fits(prior_rt, fit):
                    why = "outgrew_window"
                elif prior_rt is not None and prior_rt.state == ProfileState.ELIGIBLE and must_leave(prior_rt, now):
                    why = "fable_limit"
                else:
                    why = "unavailable"
                moves.append((prior.profile_id, to_id, why))

        # Needs an account. A subagent prefers the forced Profile; otherwise
        # (including when that Profile is unavailable — the specified
        # fallback) branches spread across eligible accounts.
        if forced_profile is not None and forced_profile.id not in attempted:
            runtime = self._runtime.get(forced_profile.id)
            # "Forced in subagents" is an explicit user choice, honoured the
            # same way a --profile pin is: it falls back only when that
            # account cannot serve AT ALL. A spent Fable week on it is not
            # that — the pin is kept, with one Activity line saying so. A
            # conversation its backend cannot hold IS that: the flag
            # documents "falls back when unavailable", so the branch spreads
            # across the accounts that can take it instead.
            if runtime is not None and runtime.state == ProfileState.ELIGIBLE and fits(runtime, fit):
                if must_leave(runtime, now):
                    self._note_fable_limit_served_anyway(pool, forced_profile.id, now,
                                                         "forced in subagents — served anyway, not rotated")
                _note_move(forced_profile.id)
                if may_create_pin:
                    self._remember_pin(key, forced_profile.id, parent_agent_id)
                return RoutingDecision(profile_id=forced_profile.id, reason="subagent_forced")

        decision = choose_for_new_branch(snapshot, now, self._branch_counts(),
                                          exclude=frozenset(attempted), fit=fit)
        _note_move(decision.profile_id)
        if decision.profile_id is not None and may_create_pin:
            self._remember_pin(key, decision.profile_id, parent_agent_id, distributed=distribute)
        return decision

    # Polling gives up to ~10 minutes of staleness, during
    # which requests for a spent model keep landing on the account that cannot
    # serve them. A 429 is the event that says "the data is already wrong".
    #
    # One read per Profile per BASE_INTERVAL_SECONDS: the whole point is to
    # replace a scheduled read, not to add one, and an account that is being
    # rate-limited is the last one to hammer with extra requests.
    _USAGE_RECHECK_MIN_INTERVAL = usage_probe.BASE_INTERVAL_SECONDS

    def _request_usage_recheck(self, profile_id: str) -> bool:
        """Ask for ONE out-of-band usage read. Caller holds no lock.

        Records a request; the daemon's existing probe tick performs it, so
        usage_probe's provider pause, per-Profile backoff and persistence all
        still apply — this only lets the read happen sooner. Returns whether
        the request was accepted, for the tests."""
        now = time.monotonic()
        with self._lock:
            last = self._usage_recheck_requested.get(profile_id)
            if last is not None and now - last < self._USAGE_RECHECK_MIN_INTERVAL:
                return False
            self._usage_recheck_requested[profile_id] = now
            self._usage_recheck_pending.add(profile_id)
            return True

    def _queue_recovered_usage_read(self, profile_id: str) -> None:
        """Caller holds self._lock. A Profile just came back from needs
        re-auth — a manual re-auth, an imported or re-pasted login, or a
        refresh_token recovery. Its usage numbers are whatever it had before
        it broke (often none), so read them now rather than at the next
        scheduled read, and wake the probe loop so "now" is seconds, not the
        30s tick. Not rate-capped like a 429 re-read: a new credential is a
        fresh start, and this happens once per recovery. The probe's provider
        pause and per-Profile backoff still apply."""
        self._usage_recheck_requested[profile_id] = time.monotonic()
        self._usage_recheck_pending.add(profile_id)
        self.usage_recheck_wakeup.set()

    def take_usage_recheck_requests(self) -> set:
        """Drains the pending set for the probe tick. Draining does NOT reset
        the rate-limit clock: a request that was honoured still counts against
        the next one."""
        with self._lock:
            pending = set(self._usage_recheck_pending)
            self._usage_recheck_pending.clear()
            return pending

    def _maybe_request_usage_recheck(self, profile_id: str, observation) -> None:
        """A 429 whose account-level windows are both comfortably below the
        switch threshold is not an account running out — it is something the
        account-level numbers cannot see, and a per-model limit is the likely
        candidate.

        Deliberately narrow: a 429 on an account that IS near its threshold is
        explained by the numbers we already have, and re-reading would tell us
        nothing we do not know."""
        if not isinstance(observation, ShortRateLimit):
            return
        rt = self._runtime.get(profile_id)
        if rt is None:
            return
        headroom = rt.switch_threshold - APPROACHING_THRESHOLD_BAND
        for percent in (rt.last_usage_percent, rt.last_usage_percent_7d):
            if percent is not None and percent >= headroom:
                return   # the account-level numbers already explain this
        self._request_usage_recheck(profile_id)

    def usage_observed_at(self) -> dict:
        """Profile id -> epoch seconds of its last usage reading."""
        with self._lock:
            return dict(self._usage_observed_at)

    def distribute_active(self) -> bool:
        """Whether any live agent was placed by distribute mode, which is
        also how a `code --distribute` session shows up while the setting
        itself is off."""
        cutoff = _pin_clock() - BRANCH_PIN_TTL_SECONDS
        with self._lock:
            return any(pin.distributed and pin.last_touch > cutoff for pin in self._branch_pins.values())

    def live_agent_counts(self) -> dict:
        """Live branch pins per Profile id, for the Dashboard: how many agents
        (main agents and subagents) each account is serving right now. Needed
        because branch-routed traffic never moves current_profile_id."""
        with self._lock:
            return self._branch_counts()

    def agents_on_account_seconds(self) -> dict:
        """Profile id -> seconds since the longest-serving live agent was
        assigned to it. "Serving for 42m" in the widget: how long this account
        has had agents on it without a break, not how long one request ran.
        Accounts with no live pin are absent."""
        now = _pin_clock()
        cutoff = now - BRANCH_PIN_TTL_SECONDS
        out: dict = {}
        with self._lock:
            for pin in self._branch_pins.values():
                if pin.last_touch > cutoff:
                    age = max(now - pin.created_at, 0.0)
                    out[pin.profile_id] = max(out.get(pin.profile_id, 0.0), age)
        return out

    def branch_pins(self) -> list[dict]:
        """Read-only view for the Dashboard: which branches are pinned where."""
        cutoff = _pin_clock() - BRANCH_PIN_TTL_SECONDS
        with self._lock:
            return [
                {"session_id": key[0], "agent_id": pin.agent_id,
                 "parent_agent_id": pin.parent_agent_id, "profile_id": pin.profile_id}
                for key, pin in self._branch_pins.items() if pin.last_touch > cutoff
            ]

    def _mark_profile_idle(self, profile_id: str) -> None:
        """Moves a Profile out of `_in_flight` and starts its "Used now"
        grace period — call with `self._lock` held. Centralized so every
        exit path (forced-return, rotate-and-continue, or a fully-drained
        response) records the same last-active timestamp; a call site that
        only did `self._in_flight.discard(...)` would make that Profile's
        "Used now" pill vanish instantly instead of fading out like the
        others."""
        self._in_flight.discard(profile_id)
        self._in_flight_since.pop(profile_id, None)
        self._last_active[profile_id] = time.monotonic()

    def _wrap_with_in_flight_clear(self, chunks, profile_id: str):
        """Clears profile_id from self._in_flight once its response is
        fully drained — or, via the same `finally`-under-GeneratorExit
        mechanism _wrap_with_usage_capture relies on (see its own
        docstring), as soon as the client disconnects mid-stream instead of
        staying marked "in use" forever."""
        if chunks is None:
            with self._lock:
                self._mark_profile_idle(profile_id)
            return chunks

        def generator():
            try:
                yield from chunks
            finally:
                with self._lock:
                    self._mark_profile_idle(profile_id)

        return generator()

    def seconds_since_last_activity(self) -> Optional[float]:
        """How long since any Profile last served a request, or None if this
        process has served none yet. Counts a request that is in flight right
        now as zero."""
        with self._lock:
            return self._seconds_since_last_activity_locked()

    def _seconds_since_last_activity_locked(self) -> Optional[float]:
        """The body of seconds_since_last_activity, for callers that already
        hold self._lock — it is a plain Lock, not an RLock, so re-entering it
        from inside the routing critical section would deadlock."""
        now = time.monotonic()
        # A slot older than the cap is a leaked/hung request, not live use;
        # ignore it here too so it can't wedge is_idle (and the updater)
        # forever — the same bound in_flight_ids() applies.
        if any(now - self._in_flight_since.get(pid, now) < self._IN_FLIGHT_MAX_SECONDS
               for pid in self._in_flight):
            return 0.0
        if not self._last_active:
            return None
        return max(0.0, now - max(self._last_active.values()))

    def is_idle(self, minimum_idle_seconds: float) -> bool:
        """True when nothing has used the pool for at least that long.

        Used to hold back anything disruptive — installing an update, then
        restarting — until it cannot interrupt a live Claude Code session.
        A daemon that has served nothing since starting counts as idle."""
        idle_for = self.seconds_since_last_activity()
        return idle_for is None or idle_for >= minimum_idle_seconds

    def serving_now_ids(self) -> set[str]:
        """Profile ids with a request literally open right now.

        in_flight_ids() deliberately also reports a Profile that finished
        within _USED_NOW_GRACE_SECONDS, because the Dashboard's "Used now"
        light must not flicker between polls. That grace makes it useless as
        an "is the pool busy" signal for a script (issue #3), so this is the
        unsmoothed view: live slots only, still bounded by
        _IN_FLIGHT_MAX_SECONDS so a leaked slot cannot pin it forever."""
        now = time.monotonic()
        with self._lock:
            return {pid for pid in self._in_flight
                    if now - self._in_flight_since.get(pid, now) < self._IN_FLIGHT_MAX_SECONDS}

    def in_flight_ids(self) -> set[str]:
        """Profile ids to show as "Used now" — either a request is
        literally being served right now (see self._in_flight's own
        docstring), or one finished within the last _USED_NOW_GRACE_SECONDS.
        The grace period exists because a quick non-streaming call can
        complete well inside the Dashboard's poll interval, making the
        indicator otherwise flicker on and off between ticks (or be missed
        entirely) instead of being reliably visible for a moment after real
        usage."""
        now = time.monotonic()
        with self._lock:
            recent = {pid for pid, ts in self._last_active.items()
                      if now - ts < self._USED_NOW_GRACE_SECONDS}
            # A slot older than the cap is a leaked/hung request, not live use;
            # drop it so it can't pin "Used now" (and is_idle) indefinitely.
            live = {pid for pid in self._in_flight
                    if now - self._in_flight_since.get(pid, now) < self._IN_FLIGHT_MAX_SECONDS}
            return live | recent

    def runtime_snapshot(self) -> dict[str, ProfileRuntime]:
        """Read-only view of live per-Profile Rotation state, synced against
        the current Pool first — safe to call anytime (e.g. from the
        Dashboard's GET /api/profiles), not just from inside handle()."""

        pool = load_pool()
        # Off the caller's thread entirely: these read the keychain (a
        # subprocess on macOS) and can make a token-refresh network call, and
        # a Dashboard or widget poll must never wait for either. A recovered
        # Profile shows up on the next poll, a second later.
        self._schedule_credential_checks(pool)
        with self._lock:
            snapshot = self._sync_snapshot(pool)
            self._runtime = {rt.profile_id: rt for rt in snapshot.profiles}
            return dict(self._runtime)

    def _schedule_credential_checks(self, pool: Pool) -> None:
        """Runs run_credential_checks_now() on a background thread, at most one
        at a time. Never raises into the caller."""
        with self._lock:
            if self._credential_check_running:
                return
            self._credential_check_running = True

        def worker():
            try:
                self.run_credential_checks_now(pool)
            except Exception:
                pass
            finally:
                with self._lock:
                    self._credential_check_running = False

        try:
            threading.Thread(target=worker, daemon=True, name="credential-checks").start()
        except Exception:
            with self._lock:
                self._credential_check_running = False

    def wait_for_credential_checks(self, timeout: float = 5.0) -> bool:
        """Blocks until the background credential-check worker is idle. For
        tests and for a caller that wants the effect before reading state;
        nothing in the request path waits."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with self._lock:
                if not self._credential_check_running:
                    return True
            time.sleep(0.01)
        return False

    def run_credential_checks_now(self, pool: Optional[Pool] = None) -> None:
        """The proactive/recovery credential refreshes, with NO lock held.

        The gateway lock stays free while the keychain and the provider's token
        endpoint are talked to: holding it across those made every Dashboard
        and widget poll queue behind a refresh (20-45s on a loaded machine).
        Each check has its own per-Profile throttle, so this is a cheap no-op
        on almost every tick.
        """
        pool = pool if pool is not None else load_pool()
        for p in pool.profiles:
            with self._lock:
                rt = self._runtime.get(p.id)
            if rt is None:
                if not p.enabled:
                    continue
                # First sync for this Profile: the preventive check still runs
                # now (a restored Profile can already be near its real
                # expiry), exactly as it did when this lived in _sync_snapshot.
                # ELIGIBLE here only enables the preventive path, never the
                # unconditional recovery one.
                rt = ProfileRuntime(profile_id=p.id, priority=p.priority,
                                    switch_threshold=p.switch_threshold, automatic=p.automatic,
                                    kind=p.kind, state=ProfileState.ELIGIBLE)
            if rt.state == ProfileState.DISABLED or not p.enabled:
                continue
            recovered = None
            try:
                if p.kind == "oauth":
                    recovered = self._maybe_check_oauth_credential(p, rt)
                elif p.kind == "codex":
                    recovered = self._maybe_check_codex_credential(p, rt)
            except Exception:
                recovered = None   # a credential check must never break a poll
            if recovered == ProfileState.AUTH_INVALID:
                with self._lock:
                    if p.id not in self._runtime:
                        # The very first poll schedules this before it has
                        # built the runtime; build it, or the mark is lost
                        # behind the rejected grant's long backoff.
                        self._runtime = {rt.profile_id: rt for rt in self._sync_snapshot(pool).profiles}
                    current = self._runtime.get(p.id)
                    if current is not None and current.state not in (ProfileState.AUTH_INVALID,
                                                                      ProfileState.DISABLED):
                        self._runtime[p.id] = _replace_runtime(current, state=ProfileState.AUTH_INVALID)
                        activity.record("error", f"{p.name} needs re-authentication",
                                         meta="its sign-in renewal was refused and the access token has expired")
                continue
            if recovered != ProfileState.ELIGIBLE:
                continue
            with self._lock:
                current = self._runtime.get(p.id)
                if current is not None and current.state == ProfileState.AUTH_INVALID:
                    self._runtime[p.id] = _replace_runtime(current, state=ProfileState.ELIGIBLE)
                    self._queue_recovered_usage_read(p.id)

    @staticmethod
    def _profile_name(pool: Pool, profile_id: str) -> str:
        p = pool.get(profile_id)
        return p.name if p is not None else profile_id

    def _record_credits(self, profile_id: str, credits) -> None:
        """Caller holds self._lock. See router.record_credits."""
        snapshot = PoolSnapshot(profiles=list(self._runtime.values()),
                                current_profile_id=self._current_profile_id)
        updated = record_credits(snapshot, profile_id, credits.has_credits, credits.balance)
        self._runtime = {rt.profile_id: rt for rt in updated.profiles}

    def _observe(self, profile_id: str, observation, now: datetime) -> None:
        snapshot = PoolSnapshot(profiles=list(self._runtime.values()), current_profile_id=self._current_profile_id)
        updated = observe(snapshot, profile_id, observation, now)
        self._runtime = {rt.profile_id: rt for rt in updated.profiles}
        if isinstance(observation, UsageSnapshot):
            self._usage_observed_at[profile_id] = time.time()
